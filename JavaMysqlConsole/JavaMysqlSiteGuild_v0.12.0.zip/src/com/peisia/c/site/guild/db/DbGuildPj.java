package com.peisia.c.site.guild.db;

import java.sql.SQLException;

import com.peisia.c.site.guild.admin.member.DtoMember;
import com.peisia.c.site.guild.member.Member;
import com.peisia.c.util.Color;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;
import com.peisia.c.util.Dice;

public class DbGuildPj extends Db{
	//직급 추가 처리
//	static public void addRank(String s) {
//		//insert into emp_rank_name values('사원');
//		String sql = String.format("insert into %s values('%s')",Db.TABLE_RANK_NAME,s);
//		Cw.wn(sql);
//		Db.dbExecuteUpdate(sql);
//	}

	//상품 리스트 출력 처리
//	static public void showProducts() {
//		String sql = String.format("select * from %s",Db.TABLE_PRODUCT);
//		Db.dbExecuteQuery(sql);
//		try {
//			while(Db.result.next()) {
//				Cw.wn(String.format("%20s. %-20s %20s 원",
//					Db.result.getString("g_no"), 
//					Db.result.getString("g_name"),  	
//					Db.result.getString("g_price") 	
//						));
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		Db.dbClose();
//	}
	//상품 구매 처리
//	static public void buyProduct(String n) {
//		////	트랜잭션 처리	////
//		////	수동 처리. 트랜잭션 처리를 위해
//		String sql = "";
//		dbInitForTransaction();
//		try {
//			sql = String.format("insert into %s (g_owner_id,g_product_no) values('%s',%s)",Db.TABLE_INVENTORY,Member.loginedId,n);
//			Cw.wn("sql 로그:"+sql);
//			st.executeUpdate(sql);
//
//			sql = String.format("update %s set g_gold = g_gold -",Db.TABLE_MEMBER);
//			sql += String.format("(select g_price from %s where g_no = %s)", Db.TABLE_PRODUCT, n);
//			sql += String.format(" where g_id = '%s'", Member.loginedId);
//			Cw.wn("sql 로그:"+sql);
//			
//			st.executeUpdate(sql);
//			con.commit();
//		} catch (SQLException e) {
//			e.printStackTrace();
//			if(con != null) {
//				try {
//					con.rollback();
//				} catch(SQLException ex) {
//					ex.printStackTrace();
//				}
//			}
//		} finally {
//			dbClose();
//		}
//	}	

	//pj 처리
	static public void procPj(String n) {
		////	트랜잭션 처리	////
		////	수동 처리. 트랜잭션 처리를 위해
		String sql = "";
		dbInitForTransaction();
		try {
			////	1
			//pj 수행함으로 수정
			sql = String.format("update %s set g_is_resolved = true where g_no = %s",Db.TABLE_PROJECT,n);
			dbExecuteUpdateForTransaction(sql);
			
			////	2
			//보상처리 - 돈
			//임시 10골드 지급
//			update guild_member set g_gold = g_gold + 10 where g_id = 'cat';
//			sql = String.format("update %s set g_gold = g_gold + %s where g_id = '%s'", Db.TABLE_MEMBER, 10, Member.loginedId);
			int rewardGold = 10;
			int rewardGoldPlus = Dice.roll(10);
			int rewardGoldSum = rewardGold + rewardGoldPlus;
			Cw.wn(String.format("[🏆보상: %s (🎲보상: %s)]",Color.gold(rewardGoldSum+"💰"), Color.gold(rewardGoldPlus+"💰")));
			sql = String.format("update %s set g_gold = g_gold + %s where g_id = '%s'", Db.TABLE_MEMBER, rewardGoldSum, Member.loginedId);
			dbExecuteUpdateForTransaction(sql);
			
			////	3
			//보상처리 - 경험치
//			update guild_member set g_exp = g_exp + 
//					(select g_exp from guild_reward_project_exp where g_no = 1)
//				    where g_id = 'cat';
			sql = String.format("update %s set g_exp = g_exp + ", Db.TABLE_MEMBER);
			sql += String.format("(select g_exp from %s where g_no = %s)", Db.TABLE_REWARD_PROJECT_EXP, n);
			sql += String.format("where g_id = '%s';", Member.loginedId);
			dbExecuteUpdateForTransaction(sql);
			
			////	4
			//소모 - vit
//			update guild_member set g_vit = g_vit - 3 where g_id = 'cat';
			sql = String.format("update %s set g_vit = g_vit - %s where g_id = '%s'", TABLE_MEMBER, 3, Member.loginedId);
			dbExecuteUpdateForTransaction(sql);
			
			//todo
			//소모로직
			//소모되는 것들
			
//			hp
//				운
//				레벨차, 난이도, 인원 등등..
//				전투 정책 세팅에 따라 동적으로..
//			mp
//				스킬 소모 정책 세팅에 따라 동적으로 될 듯
//			vit
//				vit은 소모 감소를 도와주는 스킬, 관계(npc나 다른 친한 유저간) 로 감소 시킬수 있게 하는 아이디어 추가(나중)
//			아이템 소모성..
//			장비도? 내구감소? 아니면 아예 소모? 비싼건 아예 소모면 좀 그러니까 내구 감소로 가야할듯 나중엔
					
					
			
			
			////	커밋
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			if(con != null) {
				try {
					con.rollback();
				} catch(SQLException ex) {
					ex.printStackTrace();
				}
			}
		} finally {
			dbClose();
		}
//	}			
		

		
		
	}
	
	//todo 이함수는 아직 미적용
	//케릭 스탯에 추가 (-로 감소 처리)
	//나중에 경험치 표 등등은 처음에 다 로딩하게해서 단순하게 처리하자
	static public String getSqlUserStatPlus(int hp,int hpMax,int mp,int mpMax,int vit,int vitMax, int exp, long gold, long lv) {
		String sql = String.format("update %s set", Db.TABLE_MEMBER)
		+ String.format(" g_hp = g_hp + ", hp)
		+ String.format(" g_hp_max = g_hphp_max + ", hpMax)
		+ String.format(" g_mp = g_mp + ", mp)
		+ String.format(" g_mp_max = g_mp_max + ", mpMax)
		+ String.format(" g_vit = g_vit + ", vit)
		+ String.format(" g_vit_max = g_vit_max + ", vitMax)
		+ String.format(" g_exp = g_exp + ", exp)
		+ String.format(" g_gold = g_gold + ", gold)
		+ String.format(" g_lv = g_lv + ", gold)
		+ String.format(" where g_id = '%s';", Member.loginedId);
		return sql;
	}
	
}