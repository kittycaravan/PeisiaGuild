package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganAdd {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 추가 ====");
		String n = Ci.r("추가할 조직명을 입력:");
		String i = Ci.r("조직의 장 사번 (id)를 입력:");
		DbGuild.addOrgan(n, i);
	}
}