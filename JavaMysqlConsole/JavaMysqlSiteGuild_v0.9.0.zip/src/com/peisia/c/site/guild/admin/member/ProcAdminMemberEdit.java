package com.peisia.c.site.guild.admin.member;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminMemberEdit {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 회원 - 수정 ====");
		while (true) {
			cmd = Ci.r("수정할 회원 아이디를 입력하세요: / [x] 나가기");
			if(cmd.equals("x")) {
				break;
			}
			//회원 수정
			ProcAdminMemberEditDetail.run(cmd);
			break;
		}
	}
}