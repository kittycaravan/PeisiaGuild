package com.peisia.c.site.guild.db;

import java.sql.SQLException;

import com.peisia.c.site.guild.admin.member.DtoMember;
import com.peisia.c.site.guild.member.Member;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class DbGuildMember extends Db{
	/* 로그인 처리 */
	static public boolean isProcLogin(String id, String pw) {
		String count = "";
		try {
			String sql = String.format("select count(*) from %s where g_id='%s' and g_pw='%s'", Db.TABLE_MEMBER, id, pw);
			if(Db.SQL_lOG_SHOW) Cw.wn("sql로그:"+sql);
			Db.dbExecuteQuery(sql);
//			Db.result = Db.st.executeQuery(sql);
			Db.result.next();
			count = Db.result.getString("count(*)");
			Cw.wn("찾은 회원 수:"+count);
		} catch (Exception e) { e.printStackTrace();
		}
		Db.dbClose();
		if(count.equals("1")) {
			Cw.wn("[로그인 성공]");
//			//로그인 성공 시 회원정보들도 가져옴
//			String sql = String.format("select * from %s where g_id='%s' and g_pw='%s'", Db.TABLE_MEMBER, id, pw);
//			System.out.println("sql로그:"+sql);
//			try {
//				Db.dbExecuteQuery(sql);
////				Db.result = Db.st.executeQuery(sql);
//				Db.result.next();
//				Member.no = Db.result.getString("g_no");			
//				Member.gold = Db.result.getInt("g_gold");			
//				Member.rank = Db.result.getString("g_rank");			
//				Member.className = Db.result.getString("g_class");			
//				Member.name = Db.result.getString("g_name");			
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			Db.dbClose();
			return true;	//로그인 성공
		}else {
			Db.dbClose();
			Cw.wn("[로그인 실패]");
			return false;	//로그인 실패
		}
	}	

	/* 멤버 정보 가져와서 보여주기 */
	static public void getMemberInfo() {
		String sql = String.format("select * from %s where g_id='%s'", Db.TABLE_MEMBER, Member.loginedId);
		if(Db.SQL_lOG_SHOW) Cw.wn("sql로그:"+sql);
		try {
			Db.dbExecuteQuery(sql);
			Db.result.next();
			Member.no = Db.result.getString("g_no");			
			Member.level = Db.result.getInt("g_level");			
			Member.gold = Db.result.getInt("g_gold");			
			Member.rank = Db.result.getString("g_rank");			
			Member.className = Db.result.getString("g_class");			
			Member.name = Db.result.getString("g_name");
			
			Member.hp = Db.result.getInt("g_hp");			
			Member.hpMax = Db.result.getInt("g_hp_max");			
			Member.mp = Db.result.getInt("g_mp");			
			Member.mpMax = Db.result.getInt("g_mp_max");			
			Member.vit = Db.result.getInt("g_vit");			
			Member.vitMax = Db.result.getInt("g_vit_max");
			
			Member.exp = Db.result.getInt("g_exp");			
		}catch(Exception e) {
			e.printStackTrace();
		}
		Db.dbClose();
	}
}