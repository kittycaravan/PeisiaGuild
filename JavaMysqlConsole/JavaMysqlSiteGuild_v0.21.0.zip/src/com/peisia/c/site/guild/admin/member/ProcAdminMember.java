package com.peisia.c.site.guild.admin.member;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminMember {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 회원 ====");
		loop: while (true) {
			cmd = Ci.r("[e]멤버 수정 / [x] 나가기");
			switch (cmd) {
			case "e":
				ProcAdminMemberEdit.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}