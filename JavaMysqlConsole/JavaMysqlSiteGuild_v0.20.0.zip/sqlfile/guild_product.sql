use peisia_guild;

#################################################################
#### [상품] ####
drop table guild_product;

-- create table guild_product(
-- 	g_no int primary key auto_increment,
-- 	g_name char(30) not null unique,
--     g_price bigint not null default 0
-- );

# v2
CREATE TABLE guild_product (
    g_no INT PRIMARY KEY AUTO_INCREMENT,  -- 상품 번호
    g_name VARCHAR(100) NOT NULL,         -- 상품 이름
    g_price bigint NOT NULL,              -- 상품 가격
    g_sell bigint NOT NULL,               -- 판매 가격
    g_type VARCHAR(50) NOT NULL,          -- 상품 유형
    g_e_1 VARCHAR(50),                    -- 첫 번째 효과 이름
    g_v_1 FLOAT,                          -- 첫 번째 효과 값
    g_e_2 VARCHAR(50),                    -- 두 번째 효과 이름
    g_v_2 FLOAT,                          -- 두 번째 효과 값
    g_e_3 VARCHAR(50),                    -- 세 번째 효과 이름
    g_v_3 FLOAT,                          -- 세 번째 효과 값
    g_e_4 VARCHAR(50),                    -- 네 번째 효과 이름
    g_v_4 FLOAT,                          -- 네 번째 효과 값
    g_e_5 VARCHAR(50),                    -- 다섯 번째 효과 이름
    g_v_5 FLOAT,                          -- 다섯 번째 효과 값
    g_e_6 VARCHAR(50),                    -- 여섯 번째 효과 이름
    g_v_6 FLOAT,                          -- 여섯 번째 효과 값
    g_e_7 VARCHAR(50),                    -- 일곱 번째 효과 이름
    g_v_7 FLOAT,                          -- 일곱 번째 효과 값
    g_e_8 VARCHAR(50),                    -- 여덟 번째 효과 이름
    g_v_8 FLOAT                           -- 여덟 번째 효과 값
);


insert into guild_product (g_name,g_price) values('체력물약',10);
select * from guild_product;
select count(*) from guild_product;
#백업용(이거 테이블 생성시 실행 할 것)
INSERT INTO `guild_product` VALUES (1,'체력물약(소)',10),(2,'마나물약(소)',20),(3,'낡은단검',30),(4,'낡은신발',40);

#### [ 상품구매목록(케릭터 별 보유한 아이템 목록) ] ####
drop table guild_inventory;
create table guild_inventory(
	g_no int primary key auto_increment
    ,g_owner_id char(20) not null
	,g_product_no int #나중에 아이템 전체를 목록화 및 id 부여후 여기에 대입처리 해야햠. 일단 임시로 상품id로 함.    
    ,foreign key (g_owner_id) references guild_member (g_id) on delete cascade
);
insert into guild_inventory (g_owner_id,g_product_no) values('cat',1);
select * from guild_inventory;
select count(*) from guild_inventory;

#위 둘 테이블 조인문
SELECT 
    gi.g_no AS inventory_no,
    gi.g_owner_id AS owner_id,
    gp.g_name AS product_name,
    gp.g_price AS product_price
FROM 
    guild_inventory gi #구매 목록 테이블을 gi로 축약.
JOIN #table1과 table2를 연결하는 역할. join 앞이 테이블 1 뒤가 테이블 2
    guild_product gp #상품 테이블을 gp로 축약.
ON #두 테이블 간의 연결 기준을 정의하는 곳
    gi.g_product_no = gp.g_no
where gi.g_owner_id = 'cat';

#위 둘 테이블 조인문. 소지품 출력용.
SELECT 
    gi.g_no AS inventory_no,
    gp.g_name AS product_name
FROM 
    guild_inventory gi #구매 목록 테이블을 gi로 축약.
JOIN #table1과 table2를 연결하는 역할. join 앞이 테이블 1 뒤가 테이블 2
    guild_product gp #상품 테이블을 gp로 축약.
ON #두 테이블 간의 연결 기준을 정의하는 곳
    gi.g_product_no = gp.g_no
where gi.g_owner_id = 'cat';


#### 상품 구매 금액 만큼 소지금에서 차감처리
select * from guild_member;
select * from guild_inventory;
select * from guild_product;
#구매문
insert into guild_inventory (g_owner_id,g_product_no) values('cat',1);
#차감처리
#주의 MySQL에서 UPDATE 문에서 서브쿼리를 이용해 같은 테이블을 갱신하려고 할 때, 하위 쿼리가 동일한 테이블에서 데이터를 읽는 경우에 문제
update guild_member set g_gold = g_gold -
	(select g_price from guild_product where g_no = 1)
    where g_id = 'cat';
    
update guild_member set g_gold = g_gold -(select g_price from guild_product where g_no = 3) where g_id = 'rabbit';

select g_price from guild_product where g_no = 3;

