CREATE DATABASE peisia_guild default CHARACTER SET UTF8MB4;
use peisia_guild;

show tables;
