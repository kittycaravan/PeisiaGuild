use peisia_guild;

#프로시저 조회하는 명령
SELECT ROUTINE_NAME, ROUTINE_TYPE FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_SCHEMA = 'peisia_guild' AND ROUTINE_TYPE = 'PROCEDURE';

#프로시저 삭제
drop procedure simple_procedure;


# 프로시저 내부에서 여러 명령을 사용할 수 있게 명령어 구분자를 ;에서 $$로 변경.
DELIMITER $$ 

#프로시저 생성
CREATE PROCEDURE simple_procedure()
BEGIN		# 프로시저의 본문을 BEGIN과 END로 감쌈
SELECT 'Hello, World!';				# 간단한 출력을 하는 SQL 문.
END$$		# 프로시저의 본문을 BEGIN과 END로 감쌈

DELIMITER ;

CALL simple_procedure();	# 프로시저 실행

#### 매개변수 있는 프로시저
drop procedure greet_user; #프로시저 삭제
#프로시저 생성
DELIMITER $$						
	# IN은 프로시저에 입력값을 전달할 때 사용. 					
	# 여기서는 username이라는 매개변수를 받아서 VARCHAR(50) 타입으로 처리.					
CREATE PROCEDURE greet_user(IN username VARCHAR(50), IN age int)						
BEGIN						
SELECT CONCAT(username, '안녕!', age , '살이니?');					# CONCAT: 문자열을 합치는 함수로, 입력받은 username과 'Hello, '를 합쳐서 출력.	
END$$						
						
DELIMITER ;

CALL greet_user('호양이',5);						

