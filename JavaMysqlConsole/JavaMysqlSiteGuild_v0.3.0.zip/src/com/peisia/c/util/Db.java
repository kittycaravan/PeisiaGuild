package com.peisia.c.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.peisia.c.site.guild.member.Member;

public class Db {
	static private String DB_NAME = "my_cat";
	static private String DB_ID = "root";
	static private String DB_PW = "root";
	
	/************************************************/
//	static public String tableNameBoard = "board";
	static public final String TABLE_MEMBER = "guild_member";
	static public final String TABLE_RANK_NAME = "guild_rank_name";
	static public final String TABLE_CLASS_NAME = "guild_class_name";
	static public final String TABLE_PRODUCT = "guild_product";
	static public final String TABLE_INVENTORY = "guild_inventory";
	static public final String TABLE_ORGAN = "guild_organ";
	
	/************************************************/
	static public Connection con = null;
	static public Statement st = null;
	static public ResultSet result = null;
	static public void dbInit() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB_NAME, DB_ID, DB_PW);
			Db.st = Db.con.createStatement();
		} catch (Exception e) { e.printStackTrace();
		}
	}	
	static public void dbExecuteUpdate(String query) {
		Cw.wn("전송할sql:"+query);	//로그찍기
		try {
			int resultCount = st.executeUpdate(query);
			Cw.wn("처리된 행 수:"+resultCount);
		} catch (Exception e) { e.printStackTrace();
		}
	}
	static public void dbExecuteQuery(String query) {
		Cw.wn("전송할sql:"+query);	//로그찍기
		try {
			result = st.executeQuery(query);
		} catch (Exception e) { e.printStackTrace();
		}
	}

	/* 로그인 처리 */
	static public boolean isProcLogin(String id, String pw) {
		String count = "";
		try {
			String sql = String.format("select count(*) from %s where g_id='%s' and g_pw='%s'", Db.TABLE_MEMBER, id, pw);
			System.out.println("sql로그:"+sql);
			Db.result = Db.st.executeQuery(sql);
			Db.result.next();
			count = Db.result.getString("count(*)");
			Cw.wn("찾은 회원 수:"+count);
		} catch (Exception e) { e.printStackTrace();
		}
		if(count.equals("1")) {
			Cw.wn("[로그인 성공]");
			//로그인 성공 시 회원정보들도 가져옴
			String sql = String.format("select * from %s where g_id='%s' and g_pw='%s'", Db.TABLE_MEMBER, id, pw);
			System.out.println("sql로그:"+sql);
			try {
				Db.result = Db.st.executeQuery(sql);
				Db.result.next();
				Member.no = Db.result.getString("g_no");			
				Member.gold = Db.result.getInt("g_gold");			
				Member.rank = Db.result.getString("g_rank");			
				Member.className = Db.result.getString("g_class");			
				Member.name = Db.result.getString("g_name");			
			}catch(Exception e) {
				e.printStackTrace();
			}
			return true;	//로그인 성공
		}else {
			Cw.wn("[로그인 실패]");
			return false;	//로그인 실패
		}
	}
}