package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEditName extends ProcAdminOrganEdit{
	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 ====");
		String newOrganName = Ci.r("새로운 조직명 입력:");
		DbGuild.updateOrganName(organName, newOrganName);
	}
}