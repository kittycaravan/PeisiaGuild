package com.peisia.c.site.guild.member;

public class Member {
	static public String no = null;	//사번
	static public String loginedId = null;
	static public long gold = 0;
	static public String rank = "";
	static public String className = "";
	static public String name = "";
}
