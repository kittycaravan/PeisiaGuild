package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrgan {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 ====");
		loop: while (true) {
			cmd = Ci.r("[a]조직 추가 / [e]조직 편집 / [x] 나가기");
			switch (cmd) {
			case "a":
				ProcAdminOrganAdd.run();
				break;
			case "e":
				//todo
				ProcAdminOrganEdit.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}