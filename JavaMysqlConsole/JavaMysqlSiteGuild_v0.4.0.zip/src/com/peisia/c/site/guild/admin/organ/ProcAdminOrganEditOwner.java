package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEditOwner extends ProcAdminOrganEdit{

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 - 조직장 수정 ====");
		String i = Ci.r("바꿀 조직장의 사번(no)을 입력:");
		//todo
		//db
		DbGuild.updateOrganOwner(organName, i);
		
	}
}