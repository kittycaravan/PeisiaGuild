use my_cat;

#### 회원 ####
drop table guild_member;
create table guild_member(
	g_no int primary key auto_increment, #이건 사번으로 씀. 기억해두게 해야함.
    g_id char(20) unique not null,
    g_pw char(20) not null,
    g_gold bigint unsigned default 0,
	g_rank char(20),	#직급은 공백이 허용됨. 나중에 넣어도 됨.
    foreign key (g_rank) references guild_rank_name (g_rank_name), #외래키 설정함. 목록에 있는 값만 넣을 수 있게. 
    g_class char(20),
    foreign key (g_class) references guild_class_name (g_class_name), #외래키 설정함. 목록에 있는 값만 넣을 수 있게. 
    g_name char(20)
);
insert into guild_member (g_id,g_pw) values ('cat','1234');
-- insert into guild_member (g_id,g_pw,g_rank) values ('dog','1234','주임');
insert into guild_member (g_id,g_pw,g_rank) values ('dog','1234','사원');
-- create table y(w int, foreign key (w) references x (n));
select * from guild_member;

#### 직급 ####
drop table guild_rank_name;
create table guild_rank_name(
	g_rank_name char(20) primary key
);
insert into guild_rank_name values('사원');
select * from guild_rank_name;
select count(*) from guild_rank_name;

#### 클래스(직업) 명 ####
drop table guild_class_name;
create table guild_class_name(
	g_class_name char(20) primary key
);
insert into guild_class_name values('전사');
select * from guild_class_name;
select count(*) from guild_class_name;

#### 상품 ####
drop table guild_product;
create table guild_product(
	g_no int primary key auto_increment,
	g_name char(30) not null unique,
    g_price bigint not null default 0
);
insert into guild_product (g_name,g_price) values('체력물약',10);
select * from guild_product;
select count(*) from guild_product;

#### 상품구매목록(케릭터 별 보유한 아이템 목록) ####
drop table guild_inventory;
create table guild_inventory(
	g_no int primary key auto_increment,
    g_owner_id char(20) not null,
	g_product_no int #나중에 아이템 전체를 목록화 및 id 부여후 여기에 대입처리 해야햠. 일단 임시로 상품id로 함.    
);
insert into guild_inventory (g_owner_id,g_product_no) values('cat',1);
select * from guild_inventory;
select count(*) from guild_inventory;

#위 둘 테이블 조인문
SELECT 
    gi.g_no AS inventory_no,
    gi.g_owner_id AS owner_id,
    gp.g_name AS product_name,
    gp.g_price AS product_price
FROM 
    guild_inventory gi #구매 목록 테이블을 gi로 축약.
JOIN #table1과 table2를 연결하는 역할. join 앞이 테이블 1 뒤가 테이블 2
    guild_product gp #상품 테이블을 gp로 축약.
ON #두 테이블 간의 연결 기준을 정의하는 곳
    gi.g_product_no = gp.g_no
where gi.g_owner_id = 'dog';

#### 조직 ####
drop table guild_organ;
create table guild_organ(
	g_no int primary key auto_increment,
    g_name char(30) not null unique,
    g_member_no int not null unique, #사번. 조직장.
    foreign key (g_member_no) references guild_member (g_no) #외래키 설정함. 목록에 있는 값만 넣을 수 있게. 사번
);
select * from guild_organ;

#### 조직 - 그룹 ####
drop table guild_organ_group;
create table guild_organ_group(
	g_no int primary key auto_increment,
	g_organ_no int not null,
    g_name char(30) not null,
    foreign key (g_organ_no) references guild_organ (g_no)
);
select * from guild_organ_group;

#넣을때 그룹명을 가지고 그룹을 찾아서 해당 그룹의 no 값 가져와서 insert 처리해야함.
insert into guild_organ_group (g_organ_no,g_name) values (
	(select g_no from guild_organ where g_name = '야옹파')
,'개발팀');

insert into guild_organ_group (g_organ_no,g_name) values ((select g_no from guild_organ where g_name = '야옹파') , '인사팀');

#### 조직 - 그룹 - 관계 (한 그룹이 상위 어떤 그룹에 속한지만 나타냄. 1뎁스 그룹은 상위값이 null) ####
drop table guild_organ_group_relation;
create table guild_organ_group_relation(
    g_organ_no int not null,
    g_top_group_no int,
    g_group_no int not null unique,
    foreign key (g_organ_no) references guild_organ (g_no),
    foreign key (g_group_no) references guild_organ_group (g_no)
);
select * from guild_organ_group_relation;

#인서트문이 다른 테이블에 대해서도 두개가 가능한가? 불가능한건 없을듯
insert into guild_organ_group (g_organ_no,g_name) values (
	(select g_no from guild_organ where g_name = '야옹파')
,'개발팀');

insert into guild_organ_group_relation (g_organ_no,g_top_group_no,g_group_no) values (
	(select g_no from guild_organ where g_name = '야옹파'),
	null,
	(select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no = 
		(select g_no from guild_organ where g_name = '야옹파')
    )
);


