package com.peisia.c.site.guild.admin;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminEditMall {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 상점 편집 ====");
		loop: while (true) {
			cmd = Ci.r("[a]상품 추가 / [x] 나가기");
			switch (cmd) {
			case "a":
				ProcAdminEditMallAdd.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}