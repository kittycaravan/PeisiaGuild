package com.peisia.c.site.guild.member;

public class Member {
	static public String loginedId = null;
	static public long gold = 0;
	static public String rank = "";
	static public String className = "";
	static public String name = "";
}
