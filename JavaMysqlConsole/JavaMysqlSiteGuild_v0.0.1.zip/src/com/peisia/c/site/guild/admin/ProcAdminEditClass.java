package com.peisia.c.site.guild.admin;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminEditClass {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 클래스 편집 ====");
		loop: while (true) {
			cmd = Ci.r("[a]클래스 이름 추가 / [x] 나가기");
			switch (cmd) {
			case "a":
				ProcAdminEditClassAdd.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}