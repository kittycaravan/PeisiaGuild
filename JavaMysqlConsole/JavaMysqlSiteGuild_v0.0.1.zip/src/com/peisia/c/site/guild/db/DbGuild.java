package com.peisia.c.site.guild.db;

import java.sql.SQLException;

import com.peisia.c.site.guild.member.Member;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class DbGuild {
	//직급 추가 처리
	static public void addRank(String s) {
		//insert into emp_rank_name values('사원');
		String sql = String.format("insert into %s values('%s')",Db.TABLE_RANK_NAME,s);
		Cw.wn(sql);
		Db.dbExecuteUpdate(sql);
	}
	//클래스 추가 처리
	static public void addClass(String s) {
		String sql = String.format("insert into %s values('%s')",Db.TABLE_CLASS_NAME,s);
		Cw.wn(sql);
		Db.dbExecuteUpdate(sql);
	}
	//상품 추가 처리
	static public void addProduct(String s, String s2) {
		String sql = String.format("insert into %s (g_name,g_price) values('%s',%s)",Db.TABLE_PRODUCT,s,s2);
		Cw.wn(sql);
		Db.dbExecuteUpdate(sql);
	}
	//상품 리스트 출력 처리
	static public void showProducts() {
		String sql = String.format("select * from %s",Db.TABLE_PRODUCT);
		Db.dbExecuteQuery(sql);
		try {
			while(Db.result.next()) {
				Cw.wn(String.format("%20s. %-20s %20s 원",
					Db.result.getString("g_no"), 
					Db.result.getString("g_name"),  	
					Db.result.getString("g_price") 	
						));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	//상품 구매 처리
	static public void buyProduct(String n) {
		String sql = String.format("insert into %s (g_owner_id,g_product_no) values('%s',%s)",Db.TABLE_INVENTORY,Member.loginedId,n);
		Db.dbExecuteUpdate(sql);
		//todo
		//소지금 - 처리
		
	}	
	//현재 접속한 계정의 인벤 보여주기
	static public void showInventory() {
		String sql = String.format(
				"select gi.g_no as 번호,gp.g_name as 이름 from %s gi join %s gp on gi.g_product_no = gp.g_no where gi.g_owner_id='%s'"
				,Db.TABLE_INVENTORY,Db.TABLE_PRODUCT,Member.loginedId);
		Db.dbExecuteQuery(sql);
		try {
			while(Db.result.next()) {
				Cw.wn(String.format("%20s. %-20s",
					Db.result.getString("번호"), 
					Db.result.getString("이름")  	
						));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
}