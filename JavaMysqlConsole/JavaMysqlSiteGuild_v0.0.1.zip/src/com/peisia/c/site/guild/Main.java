package com.peisia.c.site.guild;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();
	}
}