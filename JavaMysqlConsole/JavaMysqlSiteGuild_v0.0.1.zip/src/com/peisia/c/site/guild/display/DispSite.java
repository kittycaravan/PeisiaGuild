package com.peisia.c.site.guild.display;

import com.peisia.c.util.Cw;

public class DispSite {
	static private String SITE_NAME = "Peisia 길드";
	static private String VERSION = " v0.0.1";
	static private String FEAT = " sm.ahn";
	static public void entranceTitle() {
		Cw.line();
		Cw.dot();
		Cw.space(16);
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.w(FEAT);
		Cw.space(16);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}	
}
