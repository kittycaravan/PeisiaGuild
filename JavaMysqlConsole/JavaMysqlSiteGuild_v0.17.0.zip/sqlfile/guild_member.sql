use peisia_guild;

#################################################################
#### [회원] ( 주의 : [클래스(직업) 명], [직급] 테이블이 외래키로 연결되어 있어 얘네를 먼저 생성해야 이 테이블 생성 가능 ) ####
drop table guild_member;
create table guild_member(
	g_no int primary key auto_increment #이건 사번으로 씀. 기억해두게 해야함.
    ,g_id char(20) unique not null
    ,g_pw char(20) not null
    ,g_gold bigint unsigned default 0
	,g_rank char(20)	#직급은 공백이 허용됨. 나중에 넣어도 됨.
    ,foreign key (g_rank) references guild_rank_name (g_rank_name) #외래키 설정함. 목록에 있는 값만 넣을 수 있게. 
    ,g_class char(20)
    ,foreign key (g_class) references guild_class_name (g_class_name) #외래키 설정함. 목록에 있는 값만 넣을 수 있게. 
    ,g_name char(20)
    ,g_hp int not null default 100
    ,g_hp_max int not null default 100
    ,g_mp int not null default 100
    ,g_mp_max int not null default 100
    ,g_vit int not null default 100
    ,g_vit_max int not null default 100
    ,g_level int not null default 1
    ,g_exp bigint not null default 0         
);
insert into guild_member (g_id,g_pw) values ('cat','1234');
-- insert into guild_member (g_id,g_pw,g_rank) values ('dog','1234','주임');
insert into guild_member (g_id,g_pw,g_rank) values ('dog','1234','사원');
-- create table y(w int, foreign key (w) references x (n));
select * from guild_member;
update guild_member set g_gold = 1000;
delete from guild_member where g_no = 3;
#ex. pj 전투 타입 후 피해, exp 보상 처리
update guild_member set g_hp=g_hp+1,g_mp=g_mp+1,g_vit=g_vit+1,g_level=g_level+0,g_gold=g_gold+1,g_exp=g_exp+1 where g_id='cat';



#### [직급] ####
drop table guild_rank_name;
create table guild_rank_name(
	g_rank_name char(20) primary key
);
insert into guild_rank_name values('사원');
select * from guild_rank_name;
select count(*) from guild_rank_name;
#백업용(이거 테이블 생성시 실행 할 것)
INSERT INTO `guild_rank_name` VALUES ('과장'),('대리'),('부사장'),('부장'),('부회장'),('사원'),('사장'),('상무'),('이사'),('전무'),('차장'),('회장');

#### [클래스(직업) 명] ####
drop table guild_class_name;
create table guild_class_name(
	g_class_name char(20) primary key
);
insert into guild_class_name values('전사');
select * from guild_class_name;
select count(*) from guild_class_name;
#백업용(이거 테이블 생성시 실행 할 것)
INSERT INTO `guild_class_name` VALUES ('도적'),('마법사'),('전사');

