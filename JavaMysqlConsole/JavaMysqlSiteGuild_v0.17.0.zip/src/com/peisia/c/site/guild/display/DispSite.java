package com.peisia.c.site.guild.display;

import com.peisia.c.util.Cw;

public class DispSite {
	static private String SITE_NAME = "Peisia 길드";
	
	static private int VERSION_NUMBER_MAIN = 0;
	static private int VERSION_NUMBER_SUB = 17;
	static private int VERSION_NUMBER_ERROR = 0;
	
	static private String VERSION = String.format(" v%s.%s.%s",VERSION_NUMBER_MAIN,VERSION_NUMBER_SUB,VERSION_NUMBER_ERROR);
	static private String FEAT = " sm.ahn";
	static public void entranceTitle() {
		Cw.line();
		Cw.dot();
		Cw.space(15);
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.w(FEAT);
		Cw.space(15);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}	
}
