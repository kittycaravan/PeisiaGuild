package com.peisia.c.site.guild.pj;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.site.guild.db.DbGuildPj;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcPj {
	static String cmd;
	static public void run() {
		Cw.wn("======== 프로젝트 =========");
		DbGuild.showPj();
		Cw.wn("======== 내 소지품 =========");
		DbGuild.showInventory();	//임시
		
		Cw.wn("==== pj 메뉴 ====");
		cmd = Ci.r("참여할 pj 번호 입력 / [x] 나가기");
		if(cmd.equals("x")) return;
		DbGuildPj.procPj(cmd);
	}
}