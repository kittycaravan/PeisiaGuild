package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEdit {
	static protected String cmd = "";
	protected static String organName = "";
	

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 ====");
		organName = Ci.r("편집할 조직명 입력:");
		loop: while (true) {
			cmd = Ci.r("[o]조직장 수정 / [n]조직명 수정 / [d]조직 삭제 / [a]그룹추가 / [s]작업할 그룹 지정 / [x] 나가기");
			switch (cmd) {
			case "o":
				ProcAdminOrganEditOwner.run();
				break;
			case "n":
				ProcAdminOrganEditName.run();
				break;
			case "d":
				ProcAdminOrganEditDel.run();
				break;
			case "a":
				ProcAdminOrganEditGroupAdd.run();
				break;
			case "s":
				ProcAdminOrganEditGroupSelect.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}