package com.peisia.c.site.guild.admin;

import com.peisia.c.site.guild.admin.clazz.ProcAdminEditClass;
import com.peisia.c.site.guild.admin.mall.ProcAdminEditMall;
import com.peisia.c.site.guild.admin.member.ProcAdminMember;
import com.peisia.c.site.guild.admin.organ.ProcAdminOrgan;
import com.peisia.c.site.guild.admin.rank.ProcAdminEditRank;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdmin {
	static private String cmd = "";	
	
	static public void run() {
		Cw.wn("==== 관리자 메뉴 ====");
		
		adminmain:while (true) {
			cmd = Ci.r("관리자 암호를 입력하세요:");
			if(cmd.equals("1111")) {
				// 관리자 로그인 성공
				System.out.println("관리자님 어서오세요");
				
				// 관리자 모드 진행
				loop:while(true) {
					cmd = Ci.r("(편집) [1]직급 / [2]클래스 / [s]상점 / [m]회원 / [o]조직 / [x] 나가기");
					switch(cmd) {
					case "1":
						ProcAdminEditRank.run();
						break;
					case "2":
						ProcAdminEditClass.run();
						break;
					case "s":
						ProcAdminEditMall.run();
						break;
					case "m":
						ProcAdminMember.run();
						break;
					case "o":
						ProcAdminOrgan.run();
						break;
					case "x":
						break adminmain;
					}
				}				
				
			} else {
				break;	//빠져나감
			}
		}
	}
	
	static void adminRun() {
		
	}
	
}
