package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.util.Cw;

public class ProcAdminOrganEditGroupBottomGroupAdd extends ProcAdminOrganEditGroupSelect {

	public static void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 - 그룹 선택 - 하위 그룹 추가 ====");		
	}

}
