package com.peisia.c.site.guild.admin.member;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminMemberEditDetail {
	static private String cmd = "";

	static public void run(String id) {
		Cw.wn("==== 관리자 메뉴 - 회원 - 수정 - 상세 ====");
		//todo
		//가져오기
		//
		DtoMember dm = DbGuild.getMember(id);
		Cw.wn(dm.toString());
		
		loop: while (true) {
			cmd = Ci.r("[p]암호 [g]gold [r]직급 [c]클래스 [n]이름 / [x] 나가기");
			switch (cmd) {
			case "x":
				break loop;
			case "p":
				cmd = Ci.r("새 암호를 입력:");
				DbGuild.updateMemberPw(cmd,dm.id);
				break;
			case "g":
				cmd = Ci.r("새 골드를 입력:");
				DbGuild.updateMemberGold(cmd, dm.id);				
				break;
			case "r":
				cmd = Ci.r("새 직급을 입력:");
				DbGuild.updateMemberRank(cmd,dm.id);				
				break;
			case "c":
				cmd = Ci.r("새 클래스(직업)을 입력:");
				DbGuild.updateMemberClass(cmd,dm.id);				
				break;
			case "n":
				cmd = Ci.r("새 이름을 입력:");
				DbGuild.updateMemberName(cmd,dm.id);				
				break;
			}
		}
	}
}