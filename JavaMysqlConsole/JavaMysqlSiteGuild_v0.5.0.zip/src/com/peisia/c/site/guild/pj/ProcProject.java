package com.peisia.c.site.guild.pj;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ProcProject {
	static public void run() {
		Cw.wn("======== 프로젝트 =========");
		DbGuild.showInventory();
	}
}