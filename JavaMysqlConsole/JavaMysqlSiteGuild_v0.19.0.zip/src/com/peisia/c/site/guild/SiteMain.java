package com.peisia.c.site.guild;

import com.peisia.c.site.guild.admin.ProcAdmin;
import com.peisia.c.site.guild.db.DbGuildMember;
import com.peisia.c.site.guild.display.DispSite;
import com.peisia.c.site.guild.mall.ProcMall;
import com.peisia.c.site.guild.member.Member;
import com.peisia.c.site.guild.member.ProcMemberLogin;
import com.peisia.c.site.guild.member.ProcMemberRegister;
import com.peisia.c.site.guild.pj.ProcPj;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class SiteMain {
	static private String cmd = "";

	static public void run() {
//		Db.dbInit();	//주의
		
		DispSite.entranceTitle();
		loop: while (true) {
			if(Member.loginedId==null) {	// 로그아웃 상태일 때
				cmd = Ci.r("[r]회원가입 [l]로그인 [a]관리자 [e]프로그램종료");
			} else {
				DbGuildMember.getMemberInfo();
				Member.info();
				cmd = Ci.r("[l]로그아웃 [p]프로젝트 [m]상점 [a]관리자 [e]프로그램종료 ");
			}
			switch (cmd) {
			case "r":
				if(Member.loginedId==null) {	// 로그인 상태가 아니면. JavaMysqlSitePeisia_v0.0.4
					ProcMemberRegister.run();
				} else {	// 로그인 상태면
					Cw.wn("장난x");
				}				
				break;
			case "l":
				if(Member.loginedId==null) {	// 로그인 상태가 아니면
					Member.loginedId = ProcMemberLogin.run();
				} else {	// 로그인 상태면. 로그인 아이디를 null 로 바꿔주는 식으로 로그아웃 처리
					Cw.wn("[로그아웃 됨]");
					Member.loginedId = null;
				}
				break;
			case "a":
				ProcAdmin.run();
				break;
			case "e":
				Cw.wn("프로그램 종료");
				break loop;
			case "p":
				if(Member.loginedId==null) {	// 로그인 상태가 아니면.
					Cw.wn("장난x");
				} else {	// 로그인 상태면
					ProcPj.run();
				}				
				break;
			case "m":
				if(Member.loginedId==null) {	// 로그인 상태가 아니면.
					Cw.wn("장난x");
				} else {	// 로그인 상태면
					ProcMall.run();
				}				
				break;
			default:
				Cw.wn("장난x");
			}
		}
	}
}