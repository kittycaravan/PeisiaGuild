package com.peisia.c.site.guild.db;

import java.sql.SQLException;

import com.peisia.c.site.guild.admin.member.DtoMember;
import com.peisia.c.site.guild.member.Member;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class DbGuild extends Db{
	//직급 추가 처리
	static public void addRank(String s) {
		//insert into emp_rank_name values('사원');
		String sql = String.format("insert into %s values('%s')",Db.TABLE_RANK_NAME,s);
		Db.dbExecuteUpdate(sql);
	}
	//클래스 추가 처리
	static public void addClass(String s) {
		String sql = String.format("insert into %s values('%s')",Db.TABLE_CLASS_NAME,s);
		Db.dbExecuteUpdate(sql);
	}
	//상품 추가 처리
	static public void addProduct(String s, String s2) {
		String sql = String.format("insert into %s (g_name,g_price) values('%s',%s)",Db.TABLE_PRODUCT,s,s2);
		Db.dbExecuteUpdate(sql);
	}
	//상품 리스트 출력 처리
	static public void showProducts() {
		String sql = String.format("select * from %s",Db.TABLE_PRODUCT);
		Db.dbExecuteQuery(sql);
		try {
			while(Db.result.next()) {
				Cw.wn(String.format("%20s. %-20s %20s 원",
					Db.result.getString("g_no"), 
					Db.result.getString("g_name"),  	
					Db.result.getString("g_price") 	
						));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Db.dbClose();
	}
	//상품 구매 처리
	static public void buyProduct(String n) {
		////	트랜잭션 처리	////
		////	수동 처리. 트랜잭션 처리를 위해
		String sql = "";
		dbInitForTransaction();
		try {
			sql = String.format("insert into %s (g_owner_id,g_product_no) values('%s',%s)",Db.TABLE_INVENTORY,Member.loginedId,n);
			if(Db.SQL_lOG_SHOW) Cw.wn("sql 로그:"+sql);
			st.executeUpdate(sql);

			sql = String.format("update %s set g_gold = g_gold -",Db.TABLE_MEMBER);
			sql += String.format("(select g_price from %s where g_no = %s)", Db.TABLE_PRODUCT, n);
			sql += String.format(" where g_id = '%s'", Member.loginedId);
			if(Db.SQL_lOG_SHOW) Cw.wn("sql 로그:"+sql);
			
			st.executeUpdate(sql);
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			if(con != null) {
				try {
					con.rollback();
				} catch(SQLException ex) {
					ex.printStackTrace();
				}
			}
		} finally {
			dbClose();
		}
	}	
	
	//현재 접속한 계정의 인벤 보여주기
	static public void showInventory() {
		String sql = String.format(
				"select gi.g_no as 번호,gp.g_name as 이름 from %s gi join %s gp on gi.g_product_no = gp.g_no where gi.g_owner_id='%s'"
				,Db.TABLE_INVENTORY,Db.TABLE_PRODUCT,Member.loginedId);
		Db.dbExecuteQuery(sql);
		try {
			while(Db.result.next()) {
				Cw.wn(String.format("%20s. %-20s",
					Db.result.getString("번호"), 
					Db.result.getString("이름")  	
						));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Db.dbClose();
	}
	//회원 정보 가져오기
	static public DtoMember getMember(String id) {
		String sql = String.format("select * from %s where g_id='%s'",Db.TABLE_MEMBER,id);
		dbExecuteQuery(sql);
		try {
			if(result.next()) {
				return new DtoMember(
						result.getString("g_no"),
						result.getString("g_id"),
						result.getString("g_pw"),
						result.getString("g_gold"),
						result.getString("g_rank"),
						result.getString("g_class"),
						result.getString("g_name")
						);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Db.dbClose();
		return null;
	}
	//멤버 수정 - 암호
	static public void updateMemberPw(String s, String s2) {
		String sql = String.format("update %s set g_pw='%s' where g_id='%s'",Db.TABLE_MEMBER,s,s2);
		Db.dbExecuteUpdate(sql);
	}	
	//멤버 수정 - 골드
	static public void updateMemberGold(String s, String s2) {
		String sql = String.format("update %s set g_gold='%s' where g_id='%s'",Db.TABLE_MEMBER,s,s2);
		Db.dbExecuteUpdate(sql);
	}	
	//멤버 수정 - 직급
	static public void updateMemberRank(String s, String s2) {
		String sql = String.format("update %s set g_rank='%s' where g_id='%s'",Db.TABLE_MEMBER,s,s2);
		Db.dbExecuteUpdate(sql);
	}	
	//멤버 수정 - 클래스
	static public void updateMemberClass(String s, String s2) {
		String sql = String.format("update %s set g_class='%s' where g_id='%s'",Db.TABLE_MEMBER,s,s2);
		Db.dbExecuteUpdate(sql);
	}	
	//멤버 수정 - 이름
	static public void updateMemberName(String s, String s2) {
		String sql = String.format("update %s set g_name='%s' where g_id='%s'",Db.TABLE_MEMBER,s,s2);
		Db.dbExecuteUpdate(sql);
	}	
	
	//조직도 - 조직추가
	static public void addOrgan(String s, String s2) {
		String sql = String.format("insert into %s (g_name,g_member_no) values ('%s','%s')",Db.TABLE_ORGAN,s,s2);
		Db.dbExecuteUpdate(sql);
	}	
	//조직도 - 조직장 수정
	static public void updateOrganOwner(String organName, String s) {
		String sql = String.format("update %s set g_member_no = '%s' where g_name = '%s'",Db.TABLE_ORGAN,s,organName);
		Db.dbExecuteUpdate(sql);
	}	
	//조직도 - 조직명 수정
	static public void updateOrganName(String organName, String newOrganName) {
		String sql = String.format("update %s set g_name = '%s' where g_name = '%s'",Db.TABLE_ORGAN,newOrganName,organName);
		Db.dbExecuteUpdate(sql);
	}	
	//조직도 - 조직 삭제
	static public void delOrgan(String organName) {
		String sql = String.format("delete from %s where g_name = '%s'",Db.TABLE_ORGAN,organName);
		Db.dbExecuteUpdate(sql);
	}
	//조직도 - 그룹 추가
	public static void addOrganGroup(String organName, String n) {
		
		////	수동 처리. 트랜잭션 처리를 위해
		
		String sql = "";
		dbInitForTransaction();
		try {
			//insert into guild_organ_group (g_organ_no,g_name) values (
			//		(select g_no from guild_organ where g_name = '야옹파')
			//		,'개발팀');
			sql = String.format("insert into %s (g_organ_no,g_name) values ("
					+ "(select g_no from guild_organ where g_name = '%s') , '%s')",Db.TABLE_ORGAN_GROUP,organName,n);
			if(Db.SQL_lOG_SHOW) Cw.wn("sql 로그:"+sql);
			st.executeUpdate(sql);
			
			// * 주의 * sql 복잡. 서브쿼리의 서브쿼리까지 사용.
//			insert into guild_organ_group_relation (g_organ_no,g_top_group_no,g_group_no) values (
//					(select g_no from guild_organ where g_name = '야옹파'),
//					null,
//					(select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no = 
//						(select g_no from guild_organ where g_name = '야옹파')
//				    )
//				);
			
			// 참고
			// mysql 문법인 mysql 세션 변수 ( @붙인 변수 선언 ) 써서 하면 중복되는 서브쿼리를 변수화 해서 공통 처리 가능.
//			insert into guild_organ_group_relation (g_organ_no, g_top_group_no, g_group_no)
//			values (
//			    @organ_no := (select g_no from guild_organ where g_name = '야옹파'),
//			    null,
//			    (select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no = @organ_no)
//			);

			

			sql = String.format("insert into %s (g_organ_no,g_top_group_no,g_group_no) values (", Db.TABLE_ORGAN_GROUP_RELATION);
			sql += String.format("(select g_no from %s where g_name = '%s'),", Db.TABLE_ORGAN, organName);
			sql += "null,";
			sql += String.format("(select g_no from %s where g_name = '%s' and g_organ_no =",Db.TABLE_ORGAN_GROUP, n);
			sql += String.format("(select g_no from %s where g_name = '%s')", Db.TABLE_ORGAN, organName);
			sql += ")";
			sql += ")";
			
			if(Db.SQL_lOG_SHOW) Cw.wn("sql 로그:"+sql);
			
			st.executeUpdate(sql);
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			if(con != null) {
				try {
					con.rollback();
				} catch(SQLException ex) {
					ex.printStackTrace();
				}
			}
		} finally {
			dbClose();
		}
	}
	//조직도 - 그룹 - 멤버 등록
	public static void regOrganGroupMember(String organName, String groupName, String no) {
//		insert into guild_organ_group_member (g_organ_no,g_group_no,g_member_no) values (
//				(select g_no from guild_organ where g_name = '야옹파'),
//				(select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no = 
//					(select g_no from guild_organ where g_name = '야옹파')
//			    ),
//				1
//			);
		
//		String sql = String.format("insert into %s values (,yy)",Db.TABLE_ORGAN_GROUP_MEMBER,organName,groupName,no);
		
		String sql = String.format("insert into %s (g_organ_no,g_group_no,g_member_no) values (",Db.TABLE_ORGAN_GROUP_MEMBER);
		sql += String.format("(select g_no from %s where g_name = '%s'),",Db.TABLE_ORGAN, organName);
		sql += String.format("(select g_no from %s where g_name = '%s' and g_organ_no =",Db.TABLE_ORGAN_GROUP, groupName);
		sql += String.format("(select g_no from %s where g_name = '%s')", Db.TABLE_ORGAN, organName);
		sql += "),";
		sql += String.format("%s", no);
		sql += ")";
		
		Db.dbExecuteUpdate(sql);		
	}	
	//조직도 - 그룹 - 멤버 등록 취소
	public static void cancelOrganGroupMember(String organName, String groupName, String no) {
//		delete from guild_organ_group_member where 
//		g_organ_no = (select g_no from guild_organ where g_name = '야옹파')
//	    and
//	    g_group_no = (select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no =
//			(select g_no from guild_organ where g_name = '야옹파')
//		) and
//	    g_member_no = 1;
		
		String sql = String.format("delete from %s where ",Db.TABLE_ORGAN_GROUP_MEMBER);
		sql += String.format("g_organ_no = (select g_no from %s where g_name = '%s')",Db.TABLE_ORGAN, organName);
		sql += " and "; // *주의* 좌우 공백
		sql += String.format("g_group_no = (select g_no from %s where g_name = '%s' and g_organ_no =",Db.TABLE_ORGAN_GROUP, groupName);
		sql += String.format("(select g_no from %s where g_name = '%s')", Db.TABLE_ORGAN, organName);
		sql += ") and "; // *주의* 좌우 공백
		sql += String.format("g_member_no = %s", no);
		
		Db.dbExecuteUpdate(sql);		
	}
	
	//조직도 - 그룹 - 그룹장 임명
	public static void appointmentGroupLeader(String organName, String groupName, String no) {
		String sql = String.format("update %s set g_leader = true where ",Db.TABLE_ORGAN_GROUP_MEMBER);
		sql += String.format("g_organ_no = (select g_no from %s where g_name = '%s')",Db.TABLE_ORGAN, organName);
		sql += " and "; // *주의* 좌우 공백
		sql += String.format("g_group_no = (select g_no from %s where g_name = '%s' and g_organ_no =",Db.TABLE_ORGAN_GROUP, groupName);
		sql += String.format("(select g_no from %s where g_name = '%s')", Db.TABLE_ORGAN, organName);
		sql += ") and "; // *주의* 좌우 공백
		sql += String.format("g_member_no = %s", no);
		
		Db.dbExecuteUpdate(sql);		
	}
	
	//조직도 - 그룹 - 그룹장 해임
	public static void dismissalGroupLeader(String organName, String groupName, String no) {
		String sql = String.format("update %s set g_leader = false where ",Db.TABLE_ORGAN_GROUP_MEMBER);
		sql += String.format("g_organ_no = (select g_no from %s where g_name = '%s')",Db.TABLE_ORGAN, organName);
		sql += " and "; // *주의* 좌우 공백
		sql += String.format("g_group_no = (select g_no from %s where g_name = '%s' and g_organ_no =",Db.TABLE_ORGAN_GROUP, groupName);
		sql += String.format("(select g_no from %s where g_name = '%s')", Db.TABLE_ORGAN, organName);
		sql += ") and "; // *주의* 좌우 공백
		sql += String.format("g_member_no = %s", no);
		
		Db.dbExecuteUpdate(sql);		
	}
	
	//조직도 - 그룹 - 하위 그룹 추가
	public static void addOrganBottomGroup(String organName, String topGroupName, String bottomGroupName) {
		////	수동 처리. 트랜잭션 처리를 위해
		
		String sql = "";
		dbInitForTransaction();
		try {
			////	[1/2]. 그룹추가
			//insert into guild_organ_group (g_organ_no,g_name) values (
			//		(select g_no from guild_organ where g_name = '야옹파')
			//		,'개발팀');
			sql = String.format("insert into %s (g_organ_no,g_name) values ("
					+ "(select g_no from guild_organ where g_name = '%s') , '%s')",Db.TABLE_ORGAN_GROUP,organName,bottomGroupName);
			if(Db.SQL_lOG_SHOW) Cw.wn("sql 로그:"+sql);
			st.executeUpdate(sql);

			
			////	[2/2].관계 테이블에 현 그룹 no와 새 그룹명으로 등록			
			
			// * 주의 * sql 복잡. 서브쿼리의 서브쿼리까지 사용.
//			insert into guild_organ_group_relation (g_organ_no,g_top_group_no,g_group_no) values (
//					(select g_no from guild_organ where g_name = '야옹파'),
//					(select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no = 
//						@organ_no := (select g_no from guild_organ where g_name = '야옹파')
//				    ),
//					(select g_no from guild_organ_group where g_name = '지원1팀' and g_organ_no = @organ_no)
//				);
			
			sql = String.format("insert into %s (g_organ_no,g_top_group_no,g_group_no) values (", Db.TABLE_ORGAN_GROUP_RELATION);
			sql += String.format("(select g_no from %s where g_name = '%s'),", Db.TABLE_ORGAN, organName);
			sql += String.format("(select g_no from %s where g_name = '%s' and g_organ_no = ", Db.TABLE_ORGAN_GROUP, topGroupName);
			sql += String.format("@organ_no := (select g_no from %s where g_name = '%s')",Db.TABLE_ORGAN, organName);
			sql += "),";
			sql += String.format("(select g_no from %s where g_name = '%s' and g_organ_no = @organ_no)", Db.TABLE_ORGAN_GROUP, bottomGroupName);
			sql += ")";
			
			if(Db.SQL_lOG_SHOW) Cw.wn("sql 로그:"+sql);
			
			st.executeUpdate(sql);
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			if(con != null) {
				try {
					con.rollback();
				} catch(SQLException ex) {
					ex.printStackTrace();
				}
			}
		} finally {
			dbClose();
		}		
		
	}
	
	//프로젝트 - 추가 처리
	static public void addProject(String title,String level,String r,String t,String desc) {
//		insert into guild_project (g_title,g_level,g_reward_gold_no) values ('잡초뽑기',1,1);
		String sql = String.format("insert into %s (g_title,g_level,g_reward_gold_no,g_type,g_desc) values('%s',%s,%s,'%s','%s')",Db.TABLE_PROJECT,title,level,r,t,desc);
		Db.dbExecuteUpdate(sql);
	}
	//프로젝트 - list show
	public static void showPj() {
		String sql = String.format("select * from %s",Db.TABLE_PROJECT);
		Db.dbExecuteQuery(sql);
		Cw.wn(String.format("%19s. %-20s %-5s %-9s %-9s %-29s %-9s %-9s %-10s %-9s %-9s %-9s %-10s","번호","제목","레벨","해결여부","누가","언제","어디서","무엇을","어떻게","왜","보상(자격)","보상(골드)","보상(템)","보상(exp)"));
		Cw.wn(String.format("%17s%s.","","---------------------------------------------------------------------------------------------------------------------------------------"));
		try {
			while(Db.result.next()) {
				Cw.wn(String.format("%20s. %-20s %-5s %-10s %-10s %-30s %-10s %-10s %-10s %-10s %-10s %-10s %-10s",
					Db.result.getString("g_no"), 
					Db.result.getString("g_title"), 
					Db.result.getString("g_level"), 
					Db.result.getString("g_is_resolved"),  	
					Db.result.getString("g_who_no"),  	
					Db.result.getString("g_when"),  	
					Db.result.getString("g_where_no"),  	
					Db.result.getString("g_what_no"),  	
					Db.result.getString("g_how_no"),  	
					Db.result.getString("g_reward_auth_no"),  	
					Db.result.getString("g_reward_gold_no"),  	
					Db.result.getString("g_reward_item_no"),  	
					Db.result.getString("g_reward_exp_no") 	
						));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Db.dbClose();		
	}	
}