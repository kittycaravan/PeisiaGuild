package com.peisia.c.site.guild.admin.rank;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminEditRank {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 직급 편집 ====");
		loop: while (true) {
			cmd = Ci.r("[a]직급 추가 / [x] 나가기");
			switch (cmd) {
			case "a":
				ProcAdminEditRankAdd.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}