package com.peisia.c.site.guild.mall;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcMall {
	static public void run() {
		String cmd;
		Cw.wn("==== 상점 ====");
		Cw.wn("==== 상품목록 ====");
		DbGuild.showProducts();
		while (true) {
			cmd = Ci.r("구매할 상품 번호를 입력해주세요. [x] 나가기");
			if(cmd.equals("x")) {
				break;
			}
			DbGuild.buyProduct(cmd);
		}		
	}
}