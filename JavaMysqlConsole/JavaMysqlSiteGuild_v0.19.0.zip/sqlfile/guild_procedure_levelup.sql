use peisia_guild;


drop procedure level_up_procedure;
#### 현재 경험치를 확인해서 레벨업 처리하는 프로시저(한번에 경험치 획득이 많아서 2렙이상을 올려야하는 경우도 처리함)
DELIMITER $$

CREATE PROCEDURE level_up_procedure(IN member_id VARCHAR(50))
BEGIN
    DECLARE current_exp BIGINT DEFAULT 0;
    DECLARE current_level INT DEFAULT 0;
    DECLARE next_exp BIGINT DEFAULT 0;
    DECLARE level_gap INT DEFAULT 0;
    

    -- 현재 멤버의 경험치와 레벨을 가져오기
    SELECT g_exp, g_level INTO current_exp, current_level
    FROM guild_member
    WHERE g_id = member_id;

    -- 필요 경험치를 현재 레벨 기준으로 가져오기
    SELECT g_exp INTO next_exp
    FROM guild_exp_levelup
    WHERE g_level = current_level;
    
    

    -- 경험치가 필요 경험치를 초과할 동안 반복해서 레벨업
    WHILE current_exp >= next_exp DO
        -- 레벨업 처리
        UPDATE guild_member
        SET g_level = g_level + 1
        WHERE g_id = member_id;
        
        SET current_level = current_level + 1; -- 현재 레벨이 올랐으므로, current_level 값 업데이트
        set level_gap = level_gap + 1; -- 레벨 업을 몇번 했는지 계산
        
		-- 필요 경험치를 현재 레벨 기준으로 가져오기
		SELECT g_exp INTO next_exp
		FROM guild_exp_levelup
		WHERE g_level = current_level;        
    END WHILE;
    
    select level_gap; -- 레벨 차이를 출력
    
END$$

DELIMITER ;

#실행
CALL level_up_procedure('dog');

SELECT g_exp, g_level FROM guild_member WHERE g_id = 'dog';
SELECT * FROM guild_member WHERE g_id = 'dog';

    SELECT g_exp INTO next_exp
    FROM guild_exp_levelup
    WHERE g_level = current_level;