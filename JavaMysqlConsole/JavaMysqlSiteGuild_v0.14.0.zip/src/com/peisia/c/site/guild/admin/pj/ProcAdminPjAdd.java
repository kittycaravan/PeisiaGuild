package com.peisia.c.site.guild.admin.pj;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminPjAdd {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - pj - 추가 ====");
		String title = Ci.rl("제목:");
		String level = Ci.r("레벨:");
		String r = Ci.r("보상(임시로 골드 타입만):");
		DbGuild.addProject(title,level,r);
	}
//	static public void run() {
//		Cw.wn("==== 관리자 메뉴 - pj - 추가 ====");
//		loop: while (true) {
//			cmd = Ci.r("[a]임시 pj 추가하기(편집없음) / [x] 나가기");
//			switch (cmd) {
//			case "a":
//				DbGuild.addProject();
//				break;
//			case "x":
//				break loop;
//			}
//		}
//	}
}