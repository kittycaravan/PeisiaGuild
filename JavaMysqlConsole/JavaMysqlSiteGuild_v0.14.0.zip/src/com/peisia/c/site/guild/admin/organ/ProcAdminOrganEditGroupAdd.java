package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEditGroupAdd extends ProcAdminOrganEdit{
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 - 그룹추가 ====");
		cmd = Ci.r("추가할 그룹 이름을 입력: / [x] 나가기");
		if(cmd.equals("x")) {
			return;
		}
		DbGuild.addOrganGroup(organName, cmd);
	}
}