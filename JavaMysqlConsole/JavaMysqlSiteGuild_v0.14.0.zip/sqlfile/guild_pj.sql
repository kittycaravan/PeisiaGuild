use peisia_guild;

#################################################################
#### [ 프로젝트 ] ####
drop table guild_project;
create table guild_project(
	g_no int primary key auto_increment #번호
    ,g_title char(100) not null default '무제'
    ,g_level int not null default 1 #난이도 레벨 1~n
    ,g_is_resolved boolean not null default false #해결 여부
    #5w1h who when where what how why 누가 언제 어디서 무엇을 어떻게 왜
    ,g_who_no int default 1 #인원 참가 타입이라고 하자. 기본 1은 1명 아무나.
    -- ,g_when DATETIME DEFAULT (now() + INTERVAL 1 WEEK)  -- 기본값을 현재 시간으로부터 1주일 후로 설정
    ,g_when DATETIME DEFAULT (now() + INTERVAL 3 MINUTE)  -- 기본값을 현재 시간으로부터 1주일 후로 설정
	,g_where_no int default 1 #지역 타입.
    ,g_what_no int default 1 #무엇 타입
    ,g_how_no int default 1 #어떻게 타입.
    ,g_reward_auth_no int default 0 #보상(자격) 타입.
    ,g_reward_gold_no int default 1 #보상(자격) 타입.
    ,g_reward_item_no int default 0 #보상(자격) 타입.
    ,g_reward_exp_no int default 0 #보상(자격) 타입.
);
select * from guild_project;
insert into guild_project values (); #이게 되네
insert into guild_project (g_title,g_level,g_reward_gold_no) values ('잡초뽑기',1,1);

#보상지급 임시로 10골드
select * from guild_member;
update guild_member set g_gold = g_gold + 10 where g_id = 'cat';
update guild_member set g_vit = g_vit - 3 where g_id = 'cat';


#### [ 프로젝트 ] (보상) ####
drop table guild_reward;
create table guild_reward(
	g_no int primary key auto_increment #번호
    ,g_reward_type int default 1
    ,g_reward_value int default 10
);
select * from guild_reward;
insert into guild_reward values (); #이게 되네
insert into guild_reward (g_reward_type,g_reward_value) values (2,20); #이게 되네

