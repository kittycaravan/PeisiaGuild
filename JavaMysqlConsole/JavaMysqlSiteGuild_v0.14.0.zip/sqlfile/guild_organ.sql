use peisia_guild;

#################################################################
#### [ 조직 ] ####
drop table guild_organ;
create table guild_organ(
	g_no int primary key auto_increment,
    g_name char(30) not null unique,
    g_member_no int not null unique, #사번. 조직장.
    foreign key (g_member_no) references guild_member (g_no) on delete cascade #외래키 설정함. 목록에 있는 값만 넣을 수 있게. 사번. 회원삭제 시 같이 삭제되게함.
);
select * from guild_organ;

#### [ 조직 - 그룹 ] ####
drop table guild_organ_group;
create table guild_organ_group(
	g_no int primary key auto_increment,
	g_organ_no int not null,
    g_name char(30) not null,
    foreign key (g_organ_no) references guild_organ (g_no) on delete cascade
);
select * from guild_organ_group;
ALTER TABLE guild_organ_group
ADD CONSTRAINT g_organ_no_fk
FOREIGN KEY (g_organ_no) REFERENCES guild_organ(g_no)
ON DELETE CASCADE;

#넣을때 그룹명을 가지고 그룹을 찾아서 해당 그룹의 no 값 가져와서 insert 처리해야함.
insert into guild_organ_group (g_organ_no,g_name) values (
	(select g_no from guild_organ where g_name = '야옹파')
,'개발팀');

insert into guild_organ_group (g_organ_no,g_name) values ((select g_no from guild_organ where g_name = '야옹파') , '인사팀');

#### [ 조직 - 그룹 - 관계 ] (한 그룹이 상위 어떤 그룹에 속한지만 나타냄. 1뎁스 그룹은 상위값이 null) ####
drop table guild_organ_group_relation;
create table guild_organ_group_relation(
    g_organ_no int not null,
    g_top_group_no int,
    g_group_no int not null unique,
    foreign key (g_organ_no) references guild_organ (g_no) on delete cascade,
    foreign key (g_group_no) references guild_organ_group (g_no) on delete cascade
);
select * from guild_organ_group_relation;
#보기편하게
SELECT 
    gor.g_organ_no AS 조직번호,
    go.g_name AS 조직이름, 
    gor.g_top_group_no AS 상위그룹번호,
    gog_top.g_name AS 상위그룹이름,
    gor.g_group_no AS 하위그룹번호,
    gog.g_name AS 하위그룹이름
FROM 
    guild_organ_group_relation gor
JOIN 
    guild_organ go ON gor.g_organ_no = go.g_no
LEFT JOIN 
    guild_organ_group gog_top ON gor.g_top_group_no = gog_top.g_no
JOIN 
    guild_organ_group gog ON gor.g_group_no = gog.g_no;
#내버전
SELECT 
    그룹관계표.g_organ_no AS 조직번호,
    조직표.g_name AS 조직이름, 
    그룹관계표.g_top_group_no AS 상위그룹번호,
    그룹표_상위용.g_name AS 상위그룹이름,
    그룹관계표.g_group_no AS 하위그룹번호,
    그룹표_하위용.g_name AS 하위그룹이름
FROM 
    guild_organ_group_relation 그룹관계표
JOIN 
    guild_organ 조직표 ON 그룹관계표.g_organ_no = 조직표.g_no
LEFT JOIN 
    guild_organ_group 그룹표_상위용 ON 그룹관계표.g_top_group_no = 그룹표_상위용.g_no
JOIN 
    guild_organ_group 그룹표_하위용 ON 그룹관계표.g_group_no = 그룹표_하위용.g_no;
#내버전(학습용)
SELECT 
    g_organ_no AS 조직번호,
    g_top_group_no AS 상위그룹번호, #단, 바꾼 칼럼명은 조인테이블에는 못씀.
    g_group_no AS 그룹번호
FROM 
    guild_organ_group_relation 그룹관계표
join
	guild_organ 조직표
on
	그룹관계표.g_organ_no = 조직표.g_no;
#내버전(학습용) - 조인테스트
SELECT 
    g_organ_no AS 조직번호,
    g_top_group_no AS 상위그룹번호, #단, 바꾼 칼럼명은 조인테이블에는 못씀.
    g_group_no AS 그룹번호,
    #추가칼럼(조인으로)
    조직표.g_name
FROM 
    guild_organ_group_relation 그룹관계표
join
	guild_organ 조직표
on
	그룹관계표.g_organ_no = 조직표.g_no;    
    
#인서트문이 다른 테이블에 대해서도 두개가 가능한가? 불가능한건 없을듯
insert into guild_organ_group (g_organ_no,g_name) values (
	(select g_no from guild_organ where g_name = '야옹파')
,'지원1팀');

insert into guild_organ_group_relation (g_organ_no,g_top_group_no,g_group_no) values (
	(select g_no from guild_organ where g_name = '야옹파'),
	(select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no = 
		(select g_no from guild_organ where g_name = '야옹파')
    ),
	(select g_no from guild_organ_group where g_name = '지원1팀' and g_organ_no = 
		(select g_no from guild_organ where g_name = '야옹파')
    )
);

#### [ 조직 - 그룹 - 멤버 ] ####
drop table guild_organ_group_member;
create table guild_organ_group_member(
	g_no int primary key auto_increment,
    g_organ_no int not null,
    g_group_no int not null,
    g_member_no int not null,
    g_leader boolean not null default false,
    foreign key (g_organ_no) references guild_organ (g_no) on delete cascade,
    foreign key (g_group_no) references guild_organ_group (g_no) on delete cascade,
    foreign key (g_member_no) references guild_member (g_no) on delete cascade
);
select * from guild_organ_group_member;
delete from guild_organ_group_member where 
	g_organ_no = (select g_no from guild_organ where g_name = '야옹파')
    and
    g_group_no = (select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no =
		(select g_no from guild_organ where g_name = '야옹파')
	) and
    g_member_no = 1;


insert into guild_organ_group_member (g_organ_no,g_group_no,g_member_no) values (
	(select g_no from guild_organ where g_name = '야옹파'),
	(select g_no from guild_organ_group where g_name = '개발팀' and g_organ_no = 
		(select g_no from guild_organ where g_name = '야옹파')
    ),
	1
);
