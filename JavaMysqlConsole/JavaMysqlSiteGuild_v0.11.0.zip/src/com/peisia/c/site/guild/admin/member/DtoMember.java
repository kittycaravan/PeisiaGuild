package com.peisia.c.site.guild.admin.member;

public class DtoMember {
	String no;
	String id;
	String pw;
	String gold;
	String rank;
	String clazz;
	String name;
	public DtoMember(String no, String id, String pw, String gold, String rank, String clazz, String name) {
		super();
		this.no = no;
		this.id = id;
		this.pw = pw;
		this.gold = gold;
		this.rank = rank;
		this.clazz = clazz;
		this.name = name;
	}

	@Override
	public String toString() {
		return "회원정보: [no=" + no + ", id=" + id + ", pw=" + pw + ", gold=" + gold + ", rank=" + rank + ", clazz="
				+ clazz + ", name=" + name + "]";
	}
	
}
