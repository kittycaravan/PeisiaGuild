package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEditGroupLeaderDismissal extends ProcAdminOrganEditGroupSelect {

	public static void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 - 그룹 선택 - 그룹장 해임 ====");
		cmd = Ci.r("그룹장을 해임할 멤버 사번 입력 / [x] 나가기");
		if(cmd.equals("x")) {
			return;
		}
		DbGuild.dismissalGroupLeader(organName, groupName, cmd);		
	}

}
