package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEditGroupSelect extends ProcAdminOrganEdit{
	static protected String groupName = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 - 그룹 선택 ====");
		groupName = Ci.r("편집할 그룹명 입력:");
		loop: while (true) {
			cmd = Ci.r("[a]그룹장 임명 / [d]그룹장 해임 / [r]멤버 등록 / [c]멤버 등록취소 / [b]하위 그룹 추가 / [x] 나가기");
			switch (cmd) {
			case "a":
				ProcAdminOrganEditGroupLeaderAppointment.run();
				break;
			case "d":
				ProcAdminOrganEditGroupLeaderDismissal.run();
				break;
			case "r":
				ProcAdminOrganEditGroupMemberReg.run();
				break;
			case "c":
				ProcAdminOrganEditGroupMemberRegCancel.run();
				break;
			case "b":
				ProcAdminOrganEditGroupBottomGroupAdd.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}