package com.peisia.c.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.peisia.c.site.guild.member.Member;

public class Db {
	static public boolean SQL_lOG_SHOW = false;	//sql 로그를 볼건지
	
	static private String DB_NAME = "my_cat";
	static private String DB_ID = "root";
	static private String DB_PW = "root";
	
	/************************************************/
//	static public String tableNameBoard = "board";
	static public final String TABLE_MEMBER = "guild_member";
	static public final String TABLE_RANK_NAME = "guild_rank_name";
	static public final String TABLE_CLASS_NAME = "guild_class_name";
	static public final String TABLE_PRODUCT = "guild_product";
	static public final String TABLE_INVENTORY = "guild_inventory";
	static public final String TABLE_ORGAN = "guild_organ";
	static public final String TABLE_ORGAN_GROUP = "guild_organ_group";
	static public final String TABLE_ORGAN_GROUP_RELATION = "guild_organ_group_relation";
	static public final String TABLE_ORGAN_GROUP_MEMBER = "guild_organ_group_member";
	static public final String TABLE_PROJECT = "guild_project";
	static public final String TABLE_REWARD_PROJECT_EXP = "guild_reward_project_exp";
	
	/************************************************/
	static public Connection con = null;
	static public Statement st = null;
	static public ResultSet result = null;
	static public void dbInit() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB_NAME, DB_ID, DB_PW);
			Db.st = Db.con.createStatement();
		} catch (Exception e) { e.printStackTrace();
		}
	}	
	static public void dbInitForTransaction() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB_NAME, DB_ID, DB_PW);
			Db.con.setAutoCommit(false);	// 자동 커밋 끔
			Db.st = Db.con.createStatement();
		} catch (Exception e) { e.printStackTrace();
		}
	}	
	static public void dbClose() {
		try {
			if(st != null) {
				try {
					st.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		} finally {
			if(con != null) {
				try {
					con.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}	
	static public void dbExecuteUpdate(String query) {
		dbInit();
		if(SQL_lOG_SHOW) Cw.wn("전송할sql:"+query);	//로그찍기
		try {
			int resultCount = st.executeUpdate(query);
			Cw.wn("처리된 행 수:"+resultCount);
		} catch (Exception e) { e.printStackTrace();
		}
		dbClose();
	}
	static public void dbExecuteQuery(String query) {
		dbInit();
		if(SQL_lOG_SHOW) Cw.wn("전송할sql:"+query);	//로그찍기
		try {
			result = st.executeQuery(query);
		} catch (Exception e) { e.printStackTrace();
		}
		// *주의* close 는 각 쿼리 함수에서 따로 close 처리 할 것
	}


	static public void dbExecuteUpdateForTransaction(String query) throws SQLException {
		if(SQL_lOG_SHOW) Cw.wn("전송할sql:"+query);	//로그찍기
		int resultCount = st.executeUpdate(query);
		Cw.wn("처리된 행 수:"+resultCount);
//		try {
//			int resultCount = st.executeUpdate(query);
//			Cw.wn("처리된 행 수:"+resultCount);
//		} catch (Exception e) { e.printStackTrace();
//		}
	}	
}