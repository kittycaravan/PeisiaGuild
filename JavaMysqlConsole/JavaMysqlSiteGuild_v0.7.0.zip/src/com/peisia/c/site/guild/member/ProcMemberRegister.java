package com.peisia.c.site.guild.member;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ProcMemberRegister {

	/* 회원가입 처리 */
	// 일단은 id와 pw만 회원 정보로 입력하게 처리
	static private String cmd = "";
	static public void run() {
		Cw.wn("======== 회원가입 =========");
		String id="";
		String pw="";
		String rank="";
		String className="";
		String name="";
		while(true) {
			id=Ci.r("아이디");
			if(id.length()>0) {
				break;
			}else {
				Cw.wn("장난x");
			}
		}
		while(true) {
			pw=Ci.r("암호");
			if(pw.length()>0) {
				break;
			}else {
				Cw.wn("장난x");
			}
		}
		while(true) {
			rank=Ci.r("직급");
			if(pw.length()>0) {
				break;
			}else {
				Cw.wn("장난x");
			}
		}
		while(true) {
			className=Ci.r("클래스(직업)");
			if(pw.length()>0) {
				break;
			}else {
				Cw.wn("장난x");
			}
		}
		while(true) {
			name=Ci.r("이름");
			if(pw.length()>0) {
				break;
			}else {
				Cw.wn("장난x");
			}
		}
		//id,pw 를 디비에 저장. ex. insert into member values('nyang','1234');
		
		String sql = String.format("insert into %s (g_id,g_pw,g_rank,g_class,g_name) values('%s','%s','%s','%s','%s')", Db.TABLE_MEMBER, id, pw, rank, className, name);
		Db.dbExecuteUpdate(sql);
		Cw.wn("[가입완]");
	}
}