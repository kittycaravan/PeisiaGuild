package com.peisia.c.site.guild.member;

import com.peisia.c.util.Cw;

public class Member {
	static public String no = null;	//사번
	static public String loginedId = null;
	static public long gold = 0;
	static public String rank = "";
	static public String className = "";
	static public String name = "";
	
	public static void info() {
		String s = String.format("돈 %d 원 있는 %s 클래스 %s %s님 환영합니다.", Member.gold, Member.className, Member.name, Member.rank);
		Cw.wn(s);
	}
	
	
}
