package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEditGroupLeaderAppointment extends ProcAdminOrganEditGroupSelect {

	public static void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 - 그룹 선택 - 그룹장 임명 ====");
		cmd = Ci.r("그룹장으로 임명할 멤버 사번 입력 / [x] 나가기");
		if(cmd.equals("x")) {
			return;
		}
		DbGuild.appointmentGroupLeader(organName, groupName, cmd);		
	}

}
