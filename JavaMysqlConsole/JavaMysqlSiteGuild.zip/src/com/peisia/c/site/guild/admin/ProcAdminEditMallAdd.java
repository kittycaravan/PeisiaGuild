package com.peisia.c.site.guild.admin;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminEditMallAdd {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 상점 편집 - 상품 추가 ====");
		//직급 추가 처리
		String v = Ci.r("추가할 상품명을 입력해주세요:");
		String v2 = Ci.r("추가할 상품명의 가격을 입력해주세요:");
		DbGuild.addProduct(v,v2);
	}
}