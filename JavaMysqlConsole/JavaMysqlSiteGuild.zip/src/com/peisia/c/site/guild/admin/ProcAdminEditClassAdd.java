package com.peisia.c.site.guild.admin;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminEditClassAdd {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 클래스 편집 - 추가 ====");
		//직급 추가 처리
		String v = Ci.r("추가할 클래스를 입력해주세요:");
		DbGuild.addClass(v);
	}
}