package com.peisia.c.site.guild.db;

import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class DbGuild {
	//직급 추가 처리
	static public void addRank(String s) {
		//insert into emp_rank_name values('사원');
		String sql = String.format("insert into %s values('%s')",Db.TABLE_RANK_NAME,s);
		Cw.wn(sql);
		Db.dbExecuteUpdate(sql);
	}
	//클래스 추가 처리
	static public void addClass(String s) {
		String sql = String.format("insert into %s values('%s')",Db.TABLE_CLASS_NAME,s);
		Cw.wn(sql);
		Db.dbExecuteUpdate(sql);
	}
	//상품 추가 처리
	static public void addProduct(String s, String s2) {
		String sql = String.format("insert into %s (g_name,g_price) values('%s',%s)",Db.TABLE_PRODUCT,s,s2);
		Cw.wn(sql);
		Db.dbExecuteUpdate(sql);
	}

}
