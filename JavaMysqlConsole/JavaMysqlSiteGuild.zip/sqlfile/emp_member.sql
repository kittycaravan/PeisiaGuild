use my_cat;

drop table emp_member;
create table emp_member(
	e_no int primary key auto_increment,
    e_id char(20) unique not null,
    e_pw char(20) not null,
    e_gold bigint unsigned default 0,
	e_rank char(20),	#직급은 공백이 허용됨. 나중에 넣어도 됨.
    foreign key (e_rank) references emp_rank_name (e_rank_name) #외래키 설정함. 직급 목록에 있는 값만 넣을 수 있게. 
);
insert into emp_member (e_id,e_pw) values ('cat','1234');
-- insert into emp_member (e_id,e_pw,e_rank) values ('dog','1234','주임');
insert into emp_member (e_id,e_pw,e_rank) values ('dog','1234','사원');
-- create table y(w int, foreign key (w) references x (n));
select * from emp_member;


create table emp_rank_name(
	e_rank_name char(20) primary key
);
insert into emp_rank_name values('사원');
select * from emp_rank_name;
select count(*) from emp_rank_name;