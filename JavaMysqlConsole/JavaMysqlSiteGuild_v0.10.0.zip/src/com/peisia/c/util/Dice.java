package com.peisia.c.util;

public class Dice {
	static public int roll(int n) {
		return (int)(Math.random()*n+1);
	}
	static public int roll(int min, int max) {
		int n = max - min + 1;
		return (int)(Math.random()*n+min);
	}
}
