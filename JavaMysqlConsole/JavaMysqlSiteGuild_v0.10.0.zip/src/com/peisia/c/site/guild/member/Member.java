package com.peisia.c.site.guild.member;

import com.peisia.c.util.Color;
import com.peisia.c.util.Cw;

public class Member {
	static public String no = null;	//사번
	static public String loginedId = null;
	static public long gold = 0;
	static public String rank = "";
	static public String className = "";
	static public String name = "";
	
	public static void info() {
		String s = String.format("%s 있는 %s 클래스 %s %s님 환영합니다.", Color.gold(String.format("%,d",Member.gold)+"💰"), Member.className, Member.name, Member.rank);
		Cw.wn(s);
	}
	
	
}
