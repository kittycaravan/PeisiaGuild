package com.peisia.c.site.guild.admin.pj;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminPj {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - pj ====");
		loop: while (true) {
			cmd = Ci.r("[a]pj + / [x] 나가기");
			switch (cmd) {
			case "a":
				ProcAdminPjAdd.run();
				break;
			case "x":
				break loop;
			}
		}
	}
}