package com.peisia.c.site.guild.admin.organ;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminOrganEditGroupBottomGroupAdd extends ProcAdminOrganEditGroupSelect {

	public static void run() {
		Cw.wn("==== 관리자 메뉴 - 조직도 - 편집 - 그룹 선택 - 하위 그룹 추가 ====");
		cmd = Ci.r("추가할 그룹 이름 입력 / [x] 나가기");
		if(cmd.equals("x")) {
			return;
		}
		DbGuild.addOrganBottomGroup(organName, groupName, cmd);		
	}

}
