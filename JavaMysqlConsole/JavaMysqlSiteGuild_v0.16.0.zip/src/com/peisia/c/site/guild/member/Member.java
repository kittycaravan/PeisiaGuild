package com.peisia.c.site.guild.member;

import com.peisia.c.util.Color;
import com.peisia.c.util.Cw;

public class Member {
	static public String no = null;	//사번
	static public int level = 0;
	static public String loginedId = null;
	static public long gold = 0;
	static public String rank = "";
	static public String className = "";
	static public String name = "";
	static public int hp = 0;
	static public int hpMax = 0;
	static public int mp = 0;
	static public int mpMax = 0;
	static public int vit = 0;
	static public int vitMax = 0;
	static public long exp = 0;
	
	public static void info() {
		String s = String.format("[%s LV %s]<%s> {%s}", Member.level, Member.className, Member.rank, Member.name);
		s += String.format("%20s %s, %s, %s, 🏃🏻‍♂️ ‍%s/%s {exp: %s}", "", Color.gold(String.format("%,d",Member.gold)+" 💰"), Color.red("🩸 "+Member.hp+"/"+Member.hpMax), Color.blue("🩸 "+Member.mp+"/"+Member.mpMax), Member.vit, Member.vitMax, Member.exp);
		Cw.wn(s);
	}
	
	
}
