package com.peisia.c.site.guild.admin.rank;

import com.peisia.c.site.guild.db.DbGuild;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcAdminEditRankAdd {
	static private String cmd = "";

	static public void run() {
		Cw.wn("==== 관리자 메뉴 - 클래스 편집 - 추가 ====");
		//todo
		//클래스 추가 처리
		String v = Ci.r("추가할 직급을 입력해주세요:");
		DbGuild.addRank(v);
	}
}