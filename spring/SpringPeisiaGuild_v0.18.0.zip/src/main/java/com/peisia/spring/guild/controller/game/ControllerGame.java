package com.peisia.spring.guild.controller.game;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.c.util.Dice;
import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.MemberStatUpdate;
import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.dto.game.shop.Buy;
import com.peisia.spring.guild.dto.game.shop.Inventory;
import com.peisia.spring.guild.dto.game.shop.Product;
import com.peisia.spring.guild.service.game.pj.ServicePj;
import com.peisia.spring.guild.service.game.shop.ServiceShop;
import com.peisia.spring.guild.service.member.ServiceMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/game/*")
//@AllArgsConstructor
@Controller
public class ControllerGame {
		
	@Setter(onMethod_ = @Autowired)
	private ServiceShop serviceShop;
	
	@Setter(onMethod_ = @Autowired)
	private ServiceMember serviceMember;
	
	@Setter(onMethod_ = @Autowired)
	private ServicePj servicePj;
	
	private String gameLog;
	
	private void gameLog(HttpSession s, String addLog) {
		gameLog = (String) s.getAttribute("log");	// 기존 로그를 세션에서 가져옴
	    if (gameLog == null) {
	    	gameLog = "";
	    }
	    gameLog += "\n" + addLog;
	    s.setAttribute("log", gameLog);	    
	}
	
	@GetMapping("/home") public void home() {}
	@GetMapping("/lobby") public void lobby() {}
	@GetMapping("/play") public String play(HttpSession s) {
		gameLog(s,"길드에 오신것을 환영합니다.");
		
		Member m = (Member)s.getAttribute("loginedMember");
		
		////	로딩처리	////
		//-상품리스트
		s.setAttribute("products", serviceShop.loadProducts());
		s.setAttribute("inventory", serviceShop.loadInventory(m.g_id));
		//-경험치표
		HashMap<Integer,Long> expMap = serviceMember.getExpLevelupMap(); 
		s.setAttribute("expLevelupMap", expMap);
		long nextExp = expMap.get(Integer.parseInt(m.g_level));	//현재 레벨 기준, 필요 경험치 가져오기
		s.setAttribute("nextExp", nextExp);
		
		//소지품 로딩
//		new Item("전설의검",Grade.UNIQUE,Type.양손무기);
		
		return "game/house";
	}
	@GetMapping("/house") 
	public void house(HttpSession s) {
		gameLog(s,"집에 돌아왔다. 뭘 할까?");
	}
	
	@GetMapping("/house/sleep")
	public String sleep(HttpSession s) {
	    gameLog(s, "잠을 자고 활력을 모두 회복했다.");	// 로그 추가
	    Member m = (Member) s.getAttribute("loginedMember");	// 세션에서 로그인된 멤버 가져오기
	    int maxVit = Integer.parseInt(m.g_vit_max);	// 활력 회복 로직 (활력을 최대치로 바로 설정)
	    m.setG_vit(String.valueOf(maxVit));  // 활력을 최대치로 설정
	    
	    //todo
	    //디비에 실 반영
	    serviceMember.statFullVit(m.g_id);

	    s.setAttribute("loginedMember", m);	// 회복된 상태를 세션에 다시 저장
	    
	    return "game/house";	// 다시 집 화면으로 이동
	}

	@GetMapping("/shop") 
	public void shop(HttpSession s) {
		gameLog(s,"'어서오세요. 마음껏 구경하시고 골라보세요!'");
	}
	
	@GetMapping("/buy") 
	public String buy(HttpSession s, @RequestParam("no") String no, @RequestParam("price") Long price) {
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
		serviceShop.buy(new Buy(memberId, no, price));
		s.setAttribute("inventory", serviceShop.loadInventory(memberId));	//소지품 갱신
		//케릭터 상태 갱신
		Member m = serviceMember.getMemberInfo(new Member(memberId));
		s.setAttribute("loginedMember", m);
		
		gameLog(s,"물건을 샀다.");
		
		return "game/shop";
	}	
	
	@GetMapping("/pj") 
	public void pj(HttpSession s,Model m) {
		ArrayList<Pj> pjs = servicePj.list();
		m.addAttribute("pjs",pjs); //키 생략 시 객체의 타입 이름이 소문자로 변환된 형태의 키로 JSP에서 접근할 수 있음.
		
		gameLog(s,"길드 사무원이 나를 반기며 묻는다. '프로젝트에 참여하시겠어요? 현재 이런 의뢰들이 있습니다.'");
	}
	
	@GetMapping("/pjProc") 
	public String pjProc(HttpSession s, @RequestParam("no") String no) {
		Member m = (Member)s.getAttribute("loginedMember");
		
		//pj는 아직은 값 업뎃 안하기로 함(ex. 수행된 pj 여부 값 변경 등)
//		servicePj.pjProc(memberId,no);
		
		Pj pj = servicePj.getPj(no);	//pj 객체 얻어오고
		gameLog = serviceMember.procReward(pj, m.g_id);	//보상처리
		
		if(Dice.percent(40)) {	//임시: 40%확률로 활력물약(소) 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "5", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 오호~ 활력물약(소)을 얻었다.";
		}
		if(Dice.percent(30)) {	//임시: 30%확률로 체력물약(소) 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "1", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 오호~ 체력물약(소)을 얻었다.";
		}
		if(Dice.percent(20)) {	//임시: 20%확률로 마법물약(소) 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "3", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 오호~! 마법물약(소)을 얻었다.";
		}
		if(Dice.percent1000(100)) {	//임시: 10%확률로 활력물약(중) 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "6", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 아싸! 활력물약(중)을 얻었다.";
		}
		if(Dice.percent1000(80)) {	//임시: 8%확률로 체력물약(중) 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "2", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 아싸! 체력물약(중)을 얻었다.";
		}
		if(Dice.percent1000(60)) {	//임시: 6%확률로 마법물약(중) 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "4", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 아싸! 마법물약(중)을 얻었다.";
		}
		if(Dice.percent1000(35)) {	//임시: 3.5%확률로 얇은 막대기 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "7", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 아싸! 얇은 막대기 을(를) 얻었다.";
		}
		if(Dice.percent10000(25)) {	//임시: 0.25%확률로 낡은 단검 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "9", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 대박! 낡은 단검 을(를) 얻었다.";
		}
		if(Dice.percent10000(5)) {	//임시: 0.05%확률로 전설의검 얻음
			serviceShop.freeBuy(new Buy(m.g_id, "9", 0L));	//임시처리. 공짜구매를 랜덤 보상처리 대신 넣음.
			gameLog += " 전설의검 을(를) 얻었다.....";
		}

		
		s.setAttribute("inventory", serviceShop.loadInventory(m.g_id));	//소지품 갱신
		
		int levelUpCount = serviceMember.callLevelUpProcedure(m.g_id);	//프로시저로 레벨업 체크 및 처리
		
		//케릭터 상태 갱신
		m = serviceMember.getMemberInfo(new Member(m.g_id));
		s.setAttribute("loginedMember", m);
		
		if(levelUpCount>0) {
			HashMap<Integer,Long> expMap = (HashMap<Integer,Long>)s.getAttribute("expLevelupMap");
			long nextExp = expMap.get(Integer.parseInt(m.g_level));	//현재 레벨 기준, 필요 경험치 가져오기
			s.setAttribute("nextExp", nextExp);		
		}
		
		gameLog(s,gameLog);
		
		return "forward:/game/pj";	//재요청. 즉, 위 pj를 다시 실행함.
	}
	
	@GetMapping("/useItem") 
	public String useItem(HttpSession s, @RequestParam("no") String no) {
		//아이템 효과 적용
		ArrayList<Inventory> belogings = (ArrayList<Inventory>)s.getAttribute("inventory");	//소지 아이템 가져오기
		String useItemName = "";
		for(Inventory i:belogings) {
			if(i.inventory_no.equals(no)) {
				useItemName = i.product_name;
				break;
			}
		}
		
		ArrayList<Product> products = (ArrayList<Product>)s.getAttribute("products");
		
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
		gameLog = serviceMember.useItem(memberId,no,useItemName,products);
		
		s.setAttribute("inventory", serviceShop.loadInventory(memberId));	//소지품 갱신
		
		Member m = serviceMember.getMemberInfo(new Member(memberId));	//케릭터 상태 갱신
		s.setAttribute("loginedMember", m);
		
		gameLog(s,gameLog);
		
		return "game/house";
	}		
	
}
