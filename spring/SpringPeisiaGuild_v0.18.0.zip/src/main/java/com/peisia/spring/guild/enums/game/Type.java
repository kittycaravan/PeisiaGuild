package com.peisia.spring.guild.enums.game;

public enum Type {
    물약(1), 빵(2), 물(3),
    스크롤(4), 장난감(5),
    탈것학습(6),
    광석(7), 보석(8), 식재료(9),
    퀘스트(10),
    한손무기(11), 양손무기(12), 투구(13), 갑옷(14), 어깨(15), 손목(16),
    바지(17), 신발(18), 허리띠(19), 반지(20), 장신구(21), 보조무기(22),
    원거리무기(23), 화살통(24);

    // 번호 필드
    private final int code;

    // 생성자
    Type(int code) {
        this.code = code;
    }

    // 코드 반환 메소드
    public int getCode() {
        return code;
    }
}
