package com.peisia.spring.guild.dto;

import lombok.Data;

@Data
public class MemberStatUpdate {
	public String g_id;
	public int g_hp;
	public int g_hp_max;
	public int g_mp;
	public int g_mp_max;
	public int g_vit;
	public int g_vit_max;
	public int g_level;
	public long g_gold;
	public long g_exp;
	
	public MemberStatUpdate(String g_id, int g_hp, int g_hp_max, int g_mp, int g_mp_max, int g_vit, int g_vit_max,
			int g_level, long g_gold, long g_exp) {
		this.g_id = g_id;
		this.g_hp = g_hp;
		this.g_hp_max = g_hp_max;
		this.g_mp = g_mp;
		this.g_mp_max = g_mp_max;
		this.g_vit = g_vit;
		this.g_vit_max = g_vit_max;
		this.g_level = g_level;
		this.g_gold = g_gold;
		this.g_exp = g_exp;
	}
	
	
}
