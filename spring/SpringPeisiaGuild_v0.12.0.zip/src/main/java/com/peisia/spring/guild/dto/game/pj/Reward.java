package com.peisia.spring.guild.dto.game.pj;

import lombok.Data;

@Data
public class Reward {
	public String id;
	public String rewardGoldNo;
	public Reward(String id, String rewardGoldNo) {
		this.id = id;
		this.rewardGoldNo = rewardGoldNo;
	}
	
	
}
