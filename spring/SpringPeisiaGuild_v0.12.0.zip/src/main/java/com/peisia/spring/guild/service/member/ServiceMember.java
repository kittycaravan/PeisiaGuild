package com.peisia.spring.guild.service.member;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.game.pj.Pj;

public interface ServiceMember {
	public Member login(Member m);
	public void reg(Member m);
	public Member getMemberInfo(Member m);
	public void useItem(String id,String no);
	public void procReward(Pj pj, String id);
}
