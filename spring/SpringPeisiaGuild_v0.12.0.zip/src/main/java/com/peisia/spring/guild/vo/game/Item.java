package com.peisia.spring.guild.vo.game;

import com.peisia.spring.guild.enums.game.Grade;
import com.peisia.spring.guild.enums.game.Type;

import lombok.Data;

@Data
public class Item {
	public String name;
	public Grade grade;
	public Long value;
	public Type type;
	public Long priceBuy;		//구매가
	public Long priceSell;	//판매가
	public String owner;	//소유자
	
	
	public Item(String name) {
		this.name = name;
	}
	

	public Item(String name, Grade grade, Long value, Type type, Long priceBuy, Long priceSell, String owner) {
		super();
		this.name = name;
		this.grade = grade;
		this.value = value;
		this.type = type;
		this.priceBuy = priceBuy;
		this.priceSell = priceSell;
		this.owner = owner;
	}




	public Item(String name, Grade grade, Type type) {
		super();
		this.name = name;
		this.grade = grade;
		this.type = type;
	}

	


	
	
}