package com.peisia.spring.guild.controller.member;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.service.member.ServiceMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/member/*")
//@AllArgsConstructor
@Controller
public class ControllerMember {
		
	@Setter(onMethod_ = @Autowired)
	private ServiceMember service;
	
	@GetMapping("/reg")
	public void reg() {}
	
	@GetMapping("/regProc")
	public String regProc(Member m) {
		log.info("🐈🐈🐈🐈 [멤버][회원가입][처리] <컨트롤러> id:"+m.getG_id()+" pw:"+m.getG_pw() + " pwre:"+m.getG_pw_re());
		log.info(m);
		service.reg(m);
		return "home";
	}
	
	@GetMapping("/loginProc")
	public String loginProc(Member m, HttpSession s) {
		String loginedId = service.login(m);
		log.info("🐈🐈🐈🐈 [멤버][로그인][처리] <컨트롤러> id:"+loginedId);
		if(loginedId != null) {
			s.setAttribute("loginedId", loginedId);
		}
		return "home";
	}	
}
