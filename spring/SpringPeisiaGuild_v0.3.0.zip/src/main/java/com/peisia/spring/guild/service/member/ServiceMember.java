package com.peisia.spring.guild.service.member;

import com.peisia.spring.guild.dto.Member;

public interface ServiceMember {
	public String login(Member m);
	public void reg(Member m);
}
