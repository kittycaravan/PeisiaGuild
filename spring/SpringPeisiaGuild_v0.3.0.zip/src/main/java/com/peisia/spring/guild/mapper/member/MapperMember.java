package com.peisia.spring.guild.mapper.member;

import com.peisia.spring.guild.dto.Member;

public interface MapperMember {
	public String login(Member m);
	public void reg(Member m);
}
