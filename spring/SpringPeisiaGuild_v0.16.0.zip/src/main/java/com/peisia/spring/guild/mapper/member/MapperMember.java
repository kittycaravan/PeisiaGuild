package com.peisia.spring.guild.mapper.member;

import java.util.HashMap;
import java.util.List;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.MemberStatUpdate;
import com.peisia.spring.guild.dto.game.pj.Reward;
import com.peisia.spring.guild.dto.game.shop.Buy;

public interface MapperMember {
//	public String login(Member m);
	public Member login(Member m);
	public void reg(Member m);
	public void buy(Buy b);
	public Member getMemberInfo(Member m);
	public void useItem(String no);
	public void reward(Reward r);
	public void statUpdate(MemberStatUpdate m);
	
	//일단 된거
	public List<HashMap<String, Object>> getExpLevelupMap(); // 경험치 데이터를 HashMap 형태로 불러오는 메서드
	
	//프로시저 호출. 레벨이 오른 경우 레벨업한 양을 리턴함. (경험치를 한번에 많이 획득 시 2렙이상이 나올수도 있음)
	public int callLevelUpProcedure(String id);
	
}
