package com.peisia.spring.guild.service.game.pj;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.dto.game.pj.Reward;

public interface ServicePj {
	public ArrayList<Pj> list();

	public void pjProc();

	public Pj getPj(String no);
}
