package com.peisia.spring.guild.service.game.shop;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.peisia.spring.guild.dto.game.shop.Buy;
import com.peisia.spring.guild.dto.game.shop.Inventory;
import com.peisia.spring.guild.dto.game.shop.Product;
import com.peisia.spring.guild.mapper.game.shop.MapperShop;
import com.peisia.spring.guild.mapper.member.MapperMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServiceShopImpl implements ServiceShop{
	
	@Setter(onMethod_ = @Autowired)
	private MapperShop mapperShop;
	
	@Setter(onMethod_ = @Autowired)
	private MapperMember mapperMember;	

	@Override
	public ArrayList<Product> loadProducts() {
		return mapperShop.loadProducts();
	}

	@Transactional	//트랜잭션 처리함
	@Override
	public void buy(Buy b) {
		log.info("==== 섭스 구매객체:"+b);
		mapperMember.buy(b);	//구매 시 골드 차감 처리
		mapperShop.buy(b);
	}

	@Override
	public ArrayList<Inventory> loadInventory(String id) {
		return mapperShop.loadInventory(id);
	}

}
