package com.peisia.spring.guild.service.game.pj;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.guild.dto.MemberStatUpdate;
import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.dto.game.pj.Reward;
import com.peisia.spring.guild.gameconfig.CF;
import com.peisia.spring.guild.mapper.game.pj.MapperPj;
import com.peisia.spring.guild.mapper.member.MapperMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServicePjImpl implements ServicePj{
	
	@Setter(onMethod_ = @Autowired)
	private MapperPj mapperPj;
	
	@Setter(onMethod_ = @Autowired)
	private MapperMember mapperMember;
	
	@Override
	public ArrayList<Pj> list() {
		return mapperPj.list();
	}

	@Override
	public void pjProc(String id, String no) {
		Pj pj = mapperPj.get(no);	//pj 정보 가져오기
//		mapperMember.reward(new Reward(id, pj.g_reward_gold_no));	//보상처리 - 멤버에 골드 업뎃
		int useVit = 0;
		long getGold = 0;
		long getExp = 0;
		
		int useHp = 0;
		int useMp = 0;
		switch(pj.g_type) {	// pj 타입 별 분기
		case "채집":
			useVit = CF.USE_VIT_EASY;	//기본 vit 소모처리
			getGold = 10;	//todo 보상 테이블 처리
			
			//약초 랜덤 개 보상
			break;
		case "전투":
			useHp = 20;	//유저 피해 처리
			useMp = 10;	//유저 피해 처리
			useVit = CF.USE_VIT_EASY;	//기본 vit 소모처리
			
			getExp = 10;	//exp 보상 처리
			
			//todo
			//재미를 위한 랜덤성 추가
			//동렙 pj 인 경우
			//동렙 pj 인 경우 전체 체력을 0~100% 비율로 소모하도록 처리 
			
			break;
		case "호위":
			useHp = 10;	//유저 피해 처리
			useMp = 5;	//유저 피해 처리			
			useVit = CF.USE_VIT_NORMAL;	//vit을 중간 소모
			getGold = 50;	//todo 보상 테이블 처리
			getExp = 5;	//exp 보상 처리
			break;
		case "배달":
			useHp = 5;	//유저 피해 처리
			useMp = 2;	//유저 피해 처리			
			useVit = CF.USE_VIT_HARD;	//vit을 많이 소모
			getGold = 30;	//todo 보상 테이블 처리
			break;
		}
		mapperMember.statUpdate(new MemberStatUpdate(id,-useHp,0,-useMp,0,-useVit,0,0,getGold,getExp));	//각종 스탯 업뎃
		
		
	}

}
