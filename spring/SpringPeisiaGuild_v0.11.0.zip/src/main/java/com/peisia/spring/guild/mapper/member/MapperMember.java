package com.peisia.spring.guild.mapper.member;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.MemberStatUpdate;
import com.peisia.spring.guild.dto.game.pj.Reward;
import com.peisia.spring.guild.dto.game.shop.Buy;

public interface MapperMember {
//	public String login(Member m);
	public Member login(Member m);
	public void reg(Member m);
	public void buy(Buy b);
	public Member getMemberInfo(Member m);
	public void useItem(String no);
	public void reward(Reward r);
	public void statUpdate(MemberStatUpdate m);
}
