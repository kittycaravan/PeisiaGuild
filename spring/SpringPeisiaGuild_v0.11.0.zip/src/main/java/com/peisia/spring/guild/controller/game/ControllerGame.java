package com.peisia.spring.guild.controller.game;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.dto.game.pj.Reward;
import com.peisia.spring.guild.dto.game.shop.Buy;
import com.peisia.spring.guild.service.game.pj.ServicePj;
import com.peisia.spring.guild.service.game.shop.ServiceShop;
import com.peisia.spring.guild.service.member.ServiceMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/game/*")
//@AllArgsConstructor
@Controller
public class ControllerGame {
		
	@Setter(onMethod_ = @Autowired)
	private ServiceShop serviceShop;
	
	@Setter(onMethod_ = @Autowired)
	private ServiceMember serviceMember;
	
	@Setter(onMethod_ = @Autowired)
	private ServicePj servicePj;
	
	@GetMapping("/home") public void home() {}
	@GetMapping("/lobby") public void lobby() {}
	@GetMapping("/play") public String play(HttpSession s) {
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
		////	로딩처리
		//-상품리스트
		s.setAttribute("products", serviceShop.loadProducts());
		s.setAttribute("inventory", serviceShop.loadInventory(memberId));
		
		//소지품 로딩
//		new Item("전설의검",Grade.UNIQUE,Type.양손무기);
		
		return "game/house";
	}
	@GetMapping("/house") 
	public void house(HttpSession s) {}
	
	@GetMapping("/shop") 
	public void shop() {}
	
	@GetMapping("/buy") 
	public String buy(HttpSession s, @RequestParam("no") String no, @RequestParam("price") Long price) {
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
		serviceShop.buy(new Buy(memberId, no, price));
		s.setAttribute("inventory", serviceShop.loadInventory(memberId));	//소지품 갱신
		//케릭터 상태 갱신
		Member m = serviceMember.getMemberInfo(new Member(memberId));
		s.setAttribute("loginedMember", m);
		
		return "game/shop";
	}	
	
	@GetMapping("/pj") 
	public void pj(Model m) {
		ArrayList<Pj> pjs = servicePj.list();
		m.addAttribute("pjs",pjs); //키 생략 시 객체의 타입 이름이 소문자로 변환된 형태의 키로 JSP에서 접근할 수 있음.
	}
	
	@GetMapping("/pjProc") 
	public String pjProc(HttpSession s, @RequestParam("no") String no) {
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
//		servicePj.pjProc(new Reward(memberId,rewardGoldNo));
		servicePj.pjProc(memberId,no);
		
		//케릭터 상태 갱신
		Member m = serviceMember.getMemberInfo(new Member(memberId));
		s.setAttribute("loginedMember", m);		
		
		return "forward:/game/pj";	//재요청. 즉, 위 pj를 다시 실행함.
	}
	
	@GetMapping("/useItem") 
	public String useItem(HttpSession s, @RequestParam("no") String no) {
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
		serviceMember.useItem(no);
		s.setAttribute("inventory", serviceShop.loadInventory(memberId));	//소지품 갱신
//		Member m = serviceMember.getMemberInfo(new Member(memberId));	//케릭터 상태 갱신
//		s.setAttribute("loginedMember", m);
		return "game/house";
	}		
	
}
