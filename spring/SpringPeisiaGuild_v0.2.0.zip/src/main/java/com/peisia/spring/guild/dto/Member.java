package com.peisia.spring.guild.dto;

import lombok.Data;


@Data
public class Member {
	private String g_no;
	private String g_id;
	private String g_pw;
	private String g_pw_re;	// 암호 재확인
	private String g_rank;
	private String g_class;
	private String g_name;
	
	//롬복 라이브러리가 아래 게터함수, 세터함수를 자동으로 만들어줌. @Data 라고 붙이면.
	
	//게터, 게터함수, 게터메소드
//	public Long getNo() {
//		return no;
//	}
	
	//세터
//	public void setNo(Long no) {
//		this.no = no;
//	}
	
	//str_data 쪽 게터,세터도 ...

}



	
