package com.peisia.spring.guild.dto.game.shop;

import lombok.Data;

@Data
public class Inventory {
	public String inventory_no;
	public String product_name;
}
