package com.peisia.spring.guild.service.member;

import java.util.ArrayList;
import java.util.HashMap;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.MemberStatUpdate;
import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.dto.game.shop.Product;

public interface ServiceMember {
	public Member login(Member m);
	public void reg(Member m);
	public Member getMemberInfo(Member m);
	public String useItem(String id,String no,String useItemName,ArrayList<Product> products);
	public String procReward(Pj pj, String id);
	
	public HashMap<Integer, Long> getExpLevelupMap();
	
	public int callLevelUpProcedure(String id);
	
	public void statPlusUpdate(MemberStatUpdate m);
	
	public void statFullHp(String id);
	public void statFullMp(String id);
	public void statFullVit(String id);
}
