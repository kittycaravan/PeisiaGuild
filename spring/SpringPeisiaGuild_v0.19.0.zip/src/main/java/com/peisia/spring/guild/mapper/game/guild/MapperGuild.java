package com.peisia.spring.guild.mapper.game.guild;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.guild.GuildOrgan;
import com.peisia.spring.guild.dto.game.guild.GuildOrganGroup;

public interface MapperGuild {
	public ArrayList<GuildOrgan> getOrgans();
	public GuildOrgan getOrgan(String no);
	public ArrayList<GuildOrganGroup> getOrganGroup(String no);
}
