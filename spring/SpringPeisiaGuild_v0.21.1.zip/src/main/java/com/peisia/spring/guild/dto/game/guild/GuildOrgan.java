package com.peisia.spring.guild.dto.game.guild;

import lombok.Data;

@Data
public class GuildOrgan {
	public String g_no;
	public String g_name;
	public String g_member_no;
	public String g_master;
}
