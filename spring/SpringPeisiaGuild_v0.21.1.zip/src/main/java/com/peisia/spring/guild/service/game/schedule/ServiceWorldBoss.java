package com.peisia.spring.guild.service.game.schedule;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.shop.Buy;
import com.peisia.spring.guild.dto.game.shop.Inventory;
import com.peisia.spring.guild.dto.game.shop.Product;

public interface ServiceWorldBoss {
	public void updateWorldBoss();
}
