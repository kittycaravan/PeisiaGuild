package com.peisia.spring.guild.enums.game;

public enum Grade {
    TRASH(1, "T", "회색", "잡동사니", "#808080"),     // 회색 (Gray)
    NORMAL(2, "N", "흰색", "일반", "#FFFFFF"),     // 흰색 (White)
    HIGH(3, "H", "녹색", "상급", "#008000"),       // 녹색 (Green)
    MAGIC(4, "M", "파랑", "매직", "#0000FF"),      // 파랑 (Blue)
    RARE(5, "R", "보라", "레어", "#800080"),       // 보라 (Purple)
    UNIQUE(6, "U", "상아색", "유니크", "#FFFAF0"), // 상아색 (Ivory)
    SUPERRARE(7, "SR", "갈색", "전설", "#8B4513"), // 갈색 (SaddleBrown)
    SUPERSUPERRARE(8, "SSR", "오렌지색", "신화", "#FFA500"); // 오렌지색 (Orange)
//    SUPERSUPERSUPERRARE(9, "SSSR", "노란색", "신화", "#FFFF00"); // 노란색 (Yellow)

    private final int code;          // 번호
    private final String shortName;  // 약어
    private final String color;      // 한글 색상 이름
    private final String gradeName;  // 등급 이름
    private final String colorCode;  // 16진수 색상 코드

    // 생성자
    private Grade(int code, String shortName, String color, String gradeName, String colorCode) {
        this.code = code;
        this.shortName = shortName;
        this.color = color;
        this.gradeName = gradeName;
        this.colorCode = colorCode;
    }

    // Getter 메소드
    public int getCode() {
        return code;
    }

    public String getShortName() {
        return shortName;
    }

    public String getColor() {
        return color;
    }

    public String getGradeName() {
        return gradeName;
    }

    public String getColorCode() {
        return colorCode;
    }
}
