package com.peisia.spring.guild.mapper.game.pj;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.pj.Pj;

public interface MapperPj {
	public ArrayList<Pj> list();
	public Pj get(String no);
}
