package com.peisia.spring.guild.dto.game.shop;

import lombok.Data;

@Data
public class Product {
	public long g_no;
	public String g_name;
	public long g_price;
}
