package com.peisia.spring.guild.schedule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.peisia.spring.guild.service.game.pj.ServicePj;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Component
public class SchedulePjAdd {

	@Setter(onMethod_ = @Autowired)
	private ServicePj servicePj;	
	
//	@Scheduled(cron = "0 0 0/12 * * ?")	//12시간마다 실행
//	@Scheduled(cron = "0 0 * * * ?")	//1시간마다 실행
//	@Scheduled(cron = "0 */30 * * * ?")	//30분마다 실행
	@Scheduled(cron = "0 */10 * * * ?")	//10분마다 실행
//	@Scheduled(cron = "0 */5 * * * ?")	//5분마다 실행
//	@Scheduled(cron = "0 */1 * * * ?")	//1분마다 실행 ?
//	@Scheduled(cron = "*/30 * * * * ?")	//30초마다 실행 ?
//	@Scheduled(cron = "*/10 * * * * ?")	//10초마다 실행 ?
    public void addPjFieldRaid() {
		log.info("==== 10분마다 필드레이드 pj 추가");
		servicePj.addPj();
    }
}
