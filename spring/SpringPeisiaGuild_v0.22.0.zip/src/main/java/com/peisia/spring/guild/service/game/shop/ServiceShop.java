package com.peisia.spring.guild.service.game.shop;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.shop.Buy;
import com.peisia.spring.guild.dto.game.shop.Inventory;
import com.peisia.spring.guild.dto.game.shop.Product;

public interface ServiceShop {
	public ArrayList<Product> loadProducts();

	public void buy(Buy b);

	public ArrayList<Inventory> loadInventory(String id);
	
	public void freeBuy(Buy b);
}
