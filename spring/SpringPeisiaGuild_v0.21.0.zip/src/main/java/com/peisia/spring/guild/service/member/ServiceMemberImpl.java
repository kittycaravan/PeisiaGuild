package com.peisia.spring.guild.service.member;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.MemberStatUpdate;
import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.dto.game.shop.Inventory;
import com.peisia.spring.guild.dto.game.shop.Product;
import com.peisia.spring.guild.gameconfig.CF;
import com.peisia.spring.guild.mapper.member.MapperMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServiceMemberImpl implements ServiceMember{

	@Setter(onMethod_ = @Autowired)
	private MapperMember mapper;
	
	@Override
	public Member login(Member m) {
		log.info("🐈🐈🐈🐈 [로그인] <서비스>");
		return mapper.login(m);
	}

	@Override
	public void reg(Member m) {
		log.info("🐈🐈🐈🐈 [멤버][회원가입] <서비스> id:"+m.getG_id()+" pw:"+m.getG_pw() + " pwre:"+m.getG_pw_re());
		mapper.reg(m);
	}

	@Override
	public Member getMemberInfo(Member m) {
		return mapper.getMemberInfo(m);
	}

	@Override
	public String useItem(String id,String no,String useItemName,ArrayList<Product> products) {
		int plusHp = 0;
		int plusMp = 0;
		int plusVit = 0;
		
		Product usedProduct = null;
		for(Product p:products) {
			if(p.g_name.equals(useItemName)) {
				usedProduct = p;
				break;
			}
		}
		
		//효과 분기
		//일단은 간단하게
		//주의. 자료형. float 값 들어있음. 치명타 확률 같은 것 때문에 귀찮지만 다시 int 형변환 해야함
		if(usedProduct.g_e_1.equals("hp")) {
			plusHp = (int)Float.parseFloat(usedProduct.g_v_1); 
		}
		if(usedProduct.g_e_1.equals("mp")) {
			plusMp = (int)Float.parseFloat(usedProduct.g_v_1); 
		}
		if(usedProduct.g_e_1.equals("vit")) {
			plusVit = (int)Float.parseFloat(usedProduct.g_v_1); 
		}
		
		mapper.statPlusUpdate(new MemberStatUpdate(id,plusHp,0,plusMp,0,plusVit,0,0,0,0));	//효과를 케릭터에 적용
		mapper.useItem(no);	//소모처리

		String gameLog = "";
		if(plusHp>0) gameLog += " 체력회복: +"+plusHp+" 🩸"; 
		if(plusMp>0) gameLog += " 마력회복: +"+plusMp+" 💧"; 
		if(plusVit>0) gameLog += " vit회복: +"+plusVit+" 🏃🏻‍♂️";		
		
		return "아이템 사용!"+gameLog;
	}

	@Override
	public String procReward(Pj pj, String id) {
		int useVit = 0;
		long getGold = 0;
		long getExp = 0;
		
		int useHp = 0;
		int useMp = 0;
		switch(pj.g_type) {	// pj 타입 별 분기
		case "채집":
			useVit = CF.USE_VIT_EASY;	//기본 vit 소모처리
			getGold = 10;	//todo 보상 테이블 처리
			
			//약초 랜덤 개 보상
			break;
		case "전투":
			useHp = 20;	//유저 피해 처리
			useMp = 10;	//유저 피해 처리
			useVit = CF.USE_VIT_EASY;	//기본 vit 소모처리
			
			getExp = 10;	//exp 보상 처리
			
			//todo
			//재미를 위한 랜덤성 추가
			//동렙 pj 인 경우
			//동렙 pj 인 경우 전체 체력을 0~100% 비율로 소모하도록 처리 
			
			break;
		case "호위":
			useHp = 10;	//유저 피해 처리
			useMp = 5;	//유저 피해 처리			
			useVit = CF.USE_VIT_NORMAL;	//vit을 중간 소모
			getGold = 50;	//todo 보상 테이블 처리
			getExp = 5;	//exp 보상 처리
			break;
		case "배달":
			useHp = 5;	//유저 피해 처리
			useMp = 2;	//유저 피해 처리			
			useVit = CF.USE_VIT_HARD;	//vit을 많이 소모
			getGold = 30;	//todo 보상 테이블 처리
			break;
		}
	
		mapper.statPlusUpdate(new MemberStatUpdate(id,-useHp,0,-useMp,0,-useVit,0,0,getGold,getExp));	//각종 스탯 업뎃
		
		String gameLog = "";
		if(getGold>0) gameLog += " 골드획득: +"+getGold+" 💰"; 
		if(getExp>0) gameLog += " 경험치획득: +"+getExp+" 🎓"; 
		if(useHp>0) gameLog += " 체력피해: -"+useHp+" 🩸"; 
		if(useMp>0) gameLog += " 마력소모: -"+useMp+" 💧"; 
		if(useVit>0) gameLog += " vit소모: -"+useVit+" 🏃🏻‍♂️";
		
		return "프로젝트를 마쳤다! "+gameLog;
	}
	
	public HashMap<Integer, Long> getExpLevelupMap(){
		//변환 작업 일일이 손으로 해줘야 됨 =ㅅ=
        // MyBatis로부터 List<Map> 형태로 데이터 받아옴
		HashMap<Integer, Long> expLevelupMap = new HashMap<>();
		List<HashMap<String, Object>> x = mapper.getExpLevelupMap();
		for(HashMap<String, Object> e : x) {
			expLevelupMap.put((Integer)e.get("key"),(Long)e.get("value"));
		}
		return expLevelupMap;
	}
	
	public int callLevelUpProcedure(String id) {
		return mapper.callLevelUpProcedure(id);
	}
	
	public void statPlusUpdate(MemberStatUpdate m) {
		mapper.statPlusUpdate(m);	//각종 스탯 업뎃
	}

	@Override
	public void statFullHp(String id) {
		mapper.statFullHp(id);
	}

	@Override
	public void statFullMp(String id) {
		mapper.statFullMp(id);
	}

	@Override
	public void statFullVit(String id) {
		mapper.statFullVit(id);
	}
}