package com.peisia.spring.guild.gameconfig;

public class CF {
	// vit 소모
	public static final int USE_VIT_EASY = 10;
	public static final int USE_VIT_NORMAL = 20;
	public static final int USE_VIT_HARD = 30;
	public static final int USE_VIT_VERY_HARD = 50;
}
