package com.peisia.spring.guild.dto.game.schedule;

import lombok.Data;

@Data
public class WorldBoss {
	public int type;
	public int region;
	public int level;
	public WorldBoss() {}
	public WorldBoss(int type, int region, int level) {
		super();
		this.type = type;
		this.region = region;
		this.level = level;
	}
}