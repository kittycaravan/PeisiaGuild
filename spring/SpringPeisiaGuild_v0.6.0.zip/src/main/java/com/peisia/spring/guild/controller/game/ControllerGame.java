package com.peisia.spring.guild.controller.game;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.dto.game.shop.Buy;
import com.peisia.spring.guild.enums.game.Grade;
import com.peisia.spring.guild.enums.game.Type;
import com.peisia.spring.guild.service.game.shop.ServiceShop;
import com.peisia.spring.guild.vo.game.Item;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/game/*")
//@AllArgsConstructor
@Controller
public class ControllerGame {
		
	@Setter(onMethod_ = @Autowired)
	private ServiceShop serviceShop;
	
	@GetMapping("/home") public void home() {}
	@GetMapping("/lobby") public void lobby() {}
	@GetMapping("/play") public String play(HttpSession s) {
		//todo
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
		////	로딩처리
		//-상품리스트
		s.setAttribute("products", serviceShop.loadProducts());
		s.setAttribute("inventory", serviceShop.loadInventory(memberId));
		
		//소지품 로딩
//		new Item("전설의검",Grade.UNIQUE,Type.양손무기);
		
		
		
		return "game/house";
	}
	@GetMapping("/house") 
	public void house(HttpSession s) {
		//todo
		//소지품 처리
		
		//세션에도 넣고
		
		
	}
	
	@GetMapping("/shop") 
	public void shop() {
//		s.setAttribute("products", serviceShop.loadProducts());
	}
//	@GetMapping("/inventory") 
//	public void inventory(HttpSession s) {
//	}
	
	@GetMapping("/buy") 
	public String buy(HttpSession s, @RequestParam("no") String no) {
		String memberId = ((Member)s.getAttribute("loginedMember")).g_id;
		serviceShop.buy(new Buy(memberId, no));
		s.setAttribute("inventory", serviceShop.loadInventory(memberId));	//소지품 갱신
		return "game/shop";
	}	
	
	
	@GetMapping("/pj") public void pj() {}
	
//	@GetMapping("/regProc")
//	public String regProc(Member m) {
//		log.info("🐈🐈🐈🐈 [멤버][회원가입][처리] <컨트롤러> id:"+m.getG_id()+" pw:"+m.getG_pw() + " pwre:"+m.getG_pw_re());
//		log.info(m);
//		service.reg(m);
//		return "home";
//	}
//	
//	@GetMapping("/loginProc")
//	public String loginProc(Member m, HttpSession s, Model model) {
//		Member loginedMember = service.login(m);
//		log.info("🐈🐈🐈🐈 [멤버][로그인][처리] <컨트롤러> id:"+loginedMember);
//		if(loginedMember != null) {
////			s.setAttribute("loginedId", loginedMember.getG_id());
//			s.setAttribute("loginedMember",loginedMember);
//		}
//		return "home";
//	}
//	
//	@GetMapping("/logout")
//	public String logout(HttpSession s) {
//		s.invalidate();
//		return "home";
//	}
	
}
