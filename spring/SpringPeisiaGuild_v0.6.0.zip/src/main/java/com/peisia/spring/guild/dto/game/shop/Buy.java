package com.peisia.spring.guild.dto.game.shop;

import lombok.Data;

@Data
public class Buy {
	public String memberId;
	public String productNo;
	public Buy(String memberId, String productNo) {
		this.memberId = memberId;
		this.productNo = productNo;
	}
	
	
}
