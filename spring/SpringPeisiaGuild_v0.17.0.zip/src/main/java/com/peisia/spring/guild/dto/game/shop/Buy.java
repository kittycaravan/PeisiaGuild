package com.peisia.spring.guild.dto.game.shop;

import lombok.Data;

@Data
public class Buy {
	public String memberId;
	public String productNo;
	public Long price;
	public Buy(String memberId, String productNo) {
		this.memberId = memberId;
		this.productNo = productNo;
	}
	public Buy(String memberId, String productNo, Long price) {
		this.memberId = memberId;
		this.productNo = productNo;
		this.price = price;
	}
	
	
	
	
}
