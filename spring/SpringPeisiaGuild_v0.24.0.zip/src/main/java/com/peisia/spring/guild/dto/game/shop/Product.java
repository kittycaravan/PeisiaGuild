package com.peisia.spring.guild.dto.game.shop;

import lombok.Data;

@Data
public class Product {
	public long g_no;
	public String g_name;
	public long g_price;
	public long g_sell;
	public String g_type;
	public String g_e_1;
	public String g_v_1;
	public String g_e_2;
	public String g_v_2;
	public String g_e_3;
	public String g_v_3;
	public String g_e_4;
	public String g_v_4;
	public String g_e_5;
	public String g_v_5;
	public String g_e_6;
	public String g_v_6;
	public String g_e_7;
	public String g_v_7;
	public String g_e_8;
	public String g_v_8;
}
