package com.peisia.spring.guild.service.game.pj;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.c.util.Dice;
import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.mapper.game.pj.MapperPj;
import com.peisia.spring.guild.mapper.member.MapperMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServicePjImpl implements ServicePj{
	
	@Setter(onMethod_ = @Autowired)
	private MapperPj mapperPj;
	
	@Setter(onMethod_ = @Autowired)
	private MapperMember mapperMember;
	
	@Override
	public ArrayList<Pj> list() {
		return mapperPj.list();
	}

	@Override
	public void pjProc() {
		//아직은 아무 처리 안함
	}
	
	public Pj getPj(String no) {
		return mapperPj.get(no);	//pj 정보 가져오기;
	}
	
	@Override
	public void addPj() {
		//test
		log.info("==== pj 추가해보자 !");
		int level = Dice.roll(1, 20);
		int typeIndex = Dice.roll(0,1);
		String types[] = {"채집","전투"};
		String type = types[typeIndex];
		String titles[] = {"채집해줘","사냥해줘"};
		String title = titles[typeIndex];
		//임시
		//아직 보상 번호에 따라 골드, 경험치 지급 안됨. 하드코딩 값으로 지급됨
		mapperPj.addPj(new Pj(type,title,level+"","3","3"));
	}

}
