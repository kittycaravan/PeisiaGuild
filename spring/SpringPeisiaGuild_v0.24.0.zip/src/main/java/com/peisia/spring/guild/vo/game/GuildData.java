package com.peisia.spring.guild.vo.game;

import java.util.ArrayList;
import java.util.HashMap;

import com.peisia.spring.guild.dto.game.guild.GuildOrgan;

import lombok.Data;

@Data
public class GuildData {
	
	public ArrayList<GuildOrgan> organs;
	public HashMap<String,GuildOrgan> guildsByName = new HashMap<String,GuildOrgan>();
	
	
	
}