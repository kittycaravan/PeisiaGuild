package com.peisia.spring.guild.service.game.schedule;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.peisia.c.util.Dice;
import com.peisia.spring.guild.dto.game.schedule.WorldBoss;

import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServiceWorldBossImpl implements ServiceWorldBoss{
	
//	@Scheduled(cron = "0 */5 * * * ?")	//5분마다 실행
//	@Scheduled(cron = "0 */1 * * * ?")	//1분마다 실행 ?
//	@Scheduled(cron = "*/30 * * * * ?")	//30초마다 실행 ?
	@Scheduled(cron = "*/10 * * * * ?")	//10초마다 실행 ?
	public void updateWorldBoss() {
		int a = Dice.roll(6);
		int b = Dice.roll(6);
		int c = Dice.roll(6);
		new WorldBoss(a,b,c);
		log.info(String.format("==== [스케쥴] : %s지역에 %s레벨의 %s보스 등장함! ",a,b,c));
	}
}