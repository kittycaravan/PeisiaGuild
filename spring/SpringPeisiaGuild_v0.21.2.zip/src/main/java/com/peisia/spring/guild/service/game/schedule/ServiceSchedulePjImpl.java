package com.peisia.spring.guild.service.game.schedule;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.peisia.c.util.Dice;
import com.peisia.spring.guild.dto.game.schedule.WorldBoss;

import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServiceSchedulePjImpl implements ServiceSchedulePj{
	
//	@Scheduled(cron = "0 */5 * * * ?")	//5분마다 실행
//	@Scheduled(cron = "0 */1 * * * ?")	//1분마다 실행 ?
//	@Scheduled(cron = "*/30 * * * * ?")	//30초마다 실행 ?
	@Scheduled(cron = "*/30 * * * * ?")	//10초마다 실행 ?
	public void updateWorldPj() {
		int a = Dice.roll(6);
		int b = Dice.roll(6);
		int c = Dice.roll(6);
		log.info(String.format("==== [스케쥴] : 월드 pj 등장함! ",a,b,c));
	}
}