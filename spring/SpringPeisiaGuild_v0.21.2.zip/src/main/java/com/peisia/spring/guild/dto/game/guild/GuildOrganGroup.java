package com.peisia.spring.guild.dto.game.guild;

import lombok.Data;

@Data
public class GuildOrganGroup {
	public String g_no;
	public String g_name;
}
