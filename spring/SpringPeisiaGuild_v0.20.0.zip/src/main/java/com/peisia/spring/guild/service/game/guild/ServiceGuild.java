package com.peisia.spring.guild.service.game.guild;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.guild.GuildOrgan;
import com.peisia.spring.guild.vo.game.GuildOrganChart1;

public interface ServiceGuild {
//	public GuildData getGuildData();
	public ArrayList<GuildOrgan> getGuildData();
	public GuildOrganChart1 getOrgan(String no);
}
