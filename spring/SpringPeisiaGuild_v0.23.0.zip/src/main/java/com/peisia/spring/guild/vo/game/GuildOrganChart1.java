package com.peisia.spring.guild.vo.game;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.guild.GuildOrgan;
import com.peisia.spring.guild.dto.game.guild.GuildOrganGroup;

import lombok.Data;

@Data
public class GuildOrganChart1 {
	public GuildOrgan organ;
	public ArrayList<GuildOrganGroup> groups;
	
	//todo
	//하위 그룹들
	
//	public String g_no;
//	public String g_name;
//	public String g_member_no;
	
	
//	public HashMap<String,GuildOrgan> guildsByName = new HashMap<String,GuildOrgan>();
	
	
	
}