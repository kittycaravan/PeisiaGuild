package com.peisia.spring.guild.dto.game.pj;

import lombok.Data;

@Data
public class Pj {
	public String g_no;
	public String g_title;
	public String g_desc;
	public String g_level;
	public String g_type;
	public String g_is_resolved;
	public String g_where_no;
	public String g_what_no;
	public String g_how_no;
	public String g_reward_auth_no;
	public String g_reward_gold_no;
	public String g_reward_item_no;
	public String g_reward_exp_no;
	public Pj() {}
	public Pj(String g_type, String g_title, String g_level, String g_reward_gold_no, String g_reward_exp_no) {
		this.g_type = g_type;
		this.g_title = g_title;
		this.g_level = g_level;
		this.g_reward_gold_no = g_reward_gold_no;
		this.g_reward_exp_no = g_reward_exp_no;
	}
	
	
}
