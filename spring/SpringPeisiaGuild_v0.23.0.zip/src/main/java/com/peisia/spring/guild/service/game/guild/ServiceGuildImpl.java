package com.peisia.spring.guild.service.game.guild;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.guild.dto.game.guild.GuildOrgan;
import com.peisia.spring.guild.dto.game.guild.GuildOrganGroup;
import com.peisia.spring.guild.mapper.game.guild.MapperGuild;
import com.peisia.spring.guild.vo.game.GuildOrganChart1;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServiceGuildImpl implements ServiceGuild{
	
	@Setter(onMethod_ = @Autowired)
	private MapperGuild mapperGuild;
	
//	public GuildData getGuildData() {
	public ArrayList<GuildOrgan> getGuildData() {
		ArrayList<GuildOrgan> organs = mapperGuild.getOrgans();
	
		//todo
		//데이터 가공
//		guildData.organs = organs;
		
		//일단 임시로 그대로 리스트 보여주기
		
		
		
		
		return organs; 
	}

	public GuildOrganChart1 getOrgan(String no) {
		GuildOrgan go =mapperGuild.getOrgan(no);
		
		GuildOrganChart1 goc1 = new GuildOrganChart1();
		goc1.organ = go;
		
		//하위 팀 리스트 가져오기
		goc1.groups = mapperGuild.getOrganGroup(no);
		
		//todo
		//추가 데이터 처리
		return goc1;
	}
	
}
