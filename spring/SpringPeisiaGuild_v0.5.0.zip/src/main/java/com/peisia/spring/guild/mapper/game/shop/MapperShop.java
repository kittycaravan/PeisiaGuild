package com.peisia.spring.guild.mapper.game.shop;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.shop.Buy;
import com.peisia.spring.guild.dto.game.shop.Product;

public interface MapperShop {
	public ArrayList<Product> loadProducts();
	public void buy(Buy b);
}
