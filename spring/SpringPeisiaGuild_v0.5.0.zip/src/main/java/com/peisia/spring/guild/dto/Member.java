package com.peisia.spring.guild.dto;

import lombok.Data;


@Data
public class Member {
	public String g_no;
	public String g_id;
	public String g_pw;
	public String g_pw_re;	// 암호 재확인
	public String g_gold;
	public String g_rank;
	public String g_class;
	public String g_name;
	public String g_hp;
	public String g_hp_max;
	public String g_mp;
	public String g_mp_max;
	public String g_vit;
	public String g_vit_max;
	public String g_level;
	public String g_exp;
	
	//롬복 라이브러리가 아래 게터함수, 세터함수를 자동으로 만들어줌. @Data 라고 붙이면.
	
	//게터, 게터함수, 게터메소드
//	public Long getNo() {
//		return no;
//	}
	
	//세터
//	public void setNo(Long no) {
//		this.no = no;
//	}
	
	//str_data 쪽 게터,세터도 ...

}



	
