package com.peisia.spring.guild.service.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.guild.dto.Member;
import com.peisia.spring.guild.mapper.member.MapperMember;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServiceMemberImpl implements ServiceMember{

	@Setter(onMethod_ = @Autowired)
	private MapperMember mapper;	
	
	@Override
	public Member login(Member m) {
		log.info("🐈🐈🐈🐈 [로그인] <서비스>");
		return mapper.login(m);
	}

	@Override
	public void reg(Member m) {
		log.info("🐈🐈🐈🐈 [멤버][회원가입] <서비스> id:"+m.getG_id()+" pw:"+m.getG_pw() + " pwre:"+m.getG_pw_re());
		mapper.reg(m);
	}

	@Override
	public Member getMemberInfo(Member m) {
		return mapper.getMemberInfo(m);
	}

	@Override
	public void useItem(String no) {
		mapper.useItem(no);
	}	

}
