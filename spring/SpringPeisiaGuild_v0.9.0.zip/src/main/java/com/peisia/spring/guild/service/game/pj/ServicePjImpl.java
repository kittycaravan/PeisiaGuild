package com.peisia.spring.guild.service.game.pj;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.guild.dto.game.pj.Pj;
import com.peisia.spring.guild.mapper.game.pj.MapperPj;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ServicePjImpl implements ServicePj{
	
	@Setter(onMethod_ = @Autowired)
	private MapperPj mapperPj;
	
	@Override
	public ArrayList<Pj> list() {
		return mapperPj.list();
	}

}
