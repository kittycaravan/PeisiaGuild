package com.peisia.spring.guild.service.game.pj;

import java.util.ArrayList;

import com.peisia.spring.guild.dto.game.pj.Pj;

public interface ServicePj {
	public ArrayList<Pj> list();
}
