package com.peisia.spring.guild.dto.game.pj;

import lombok.Data;

@Data
public class Pj {
	public String g_no;
	public String g_is_resolved;
	public String g_where_no;
	public String g_what_no;
	public String g_how_no;
	public String g_reward_auth_no;
	public String g_reward_gold_no;
	public String g_reward_item_no;
	public String g_reward_exp_no;
}
